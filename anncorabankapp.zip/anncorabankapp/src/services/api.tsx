import axios, {AxiosError} from 'axios';
import config from '../config';
import {store} from '../redux/store';
import {AuthService} from './AuthService';

export function setupAPIClient() {
	const api = axios.create({
		baseURL: config.generalApiPath,
		headers: {
			'Access-Control-Allow-Origin': '*',
			token_cliente: config.clientToken,
		},
	});

	api.interceptors.request.use(async config => {
		const {token} = store.getState().authReducer;
		if (token) {
			config.headers.Authorization = `Bearer ${token}`;
		}
		return config;
	});

	api.interceptors.response.use(
		response => {
			if (process.env.NODE_ENV === 'development') {
				if (response.config.method) {
					console.log(
						'Request:',
						'method',
						response.config.method,
						'url',
						response.config.url,
						response,
					);
				} else {
					console.log('Response:', 'url', response.config.url, response);
				}
			}
			return response;
		},
		async (error: AxiosError) => {
			if (error.response?.status === 401) {
				// const tokenExpired = await AuthService.isTokenExpired();
				// if (tokenExpired) {
				// 	AuthService.redirectToInitialScreen();
				// }
			}
			return Promise.reject(error);
		},
	);

	return api;
}
