import jwt_decode from 'jwt-decode';

import { NavigationContainerRef } from '@react-navigation/native';
import { store } from '../redux/store';

import {reset as resetAuth} from '../redux/actions/authActions';
import {reset as resetUser} from '../redux/actions/userActions';
import {reset as resetSaldo} from '../redux/actions/saldoActions';
import {reset as resetRegisterActions} from '../redux/actions/userRegisterActions';

export class AuthService {
  private static navigation: NavigationContainerRef<any> | null = null;

  static setNavigation(navigation: NavigationContainerRef<any> | null) {
    AuthService.navigation = navigation;
  }

  static async getToken(): Promise<string | undefined> {
    try {
      const { token }: any = store.getState().authReducer;
      return token;
    } catch (error) {
      console.error('Error while getting token', error);
      return undefined;
    }
  }

  static async isTokenExpired(): Promise<boolean> {
    const token = await AuthService.getToken();
    if (!token) {
      return false;
    }
    const decodedToken: any = jwt_decode(token);
		const dateExpire = new Date(decodedToken.expire);
		const dateCurrent = new Date();
    return dateExpire.getTime() < dateCurrent.getTime();
  }

	static async isValidToken(): Promise<boolean> {
		const token = await AuthService.getToken();
		if (!token) {
			return false;
		}
		const decodedToken: any = jwt_decode(token);
		const dateExpire = new Date(decodedToken.expire);
		const dateCurrent = new Date();
		return dateExpire.getTime() > dateCurrent.getTime();
	}

  static redirectToInitialScreen() {
    if (AuthService.navigation) {
      AuthService.navigation.navigate('PaginaInicial');
    }
  }

	static redirectToLoginScreen() {
		if (AuthService.navigation) {
			AuthService.navigation.navigate('LoginContainer', {
				screen: 'Login',
			});
		}
	}

  static redirectToHome() {
    if (AuthService.navigation) {
      AuthService.navigation.navigate('ContainerTabs');
    }
  }

	static resetRedux() {
		store.dispatch(resetAuth());
		store.dispatch(resetUser());
		store.dispatch(resetSaldo());
		store.dispatch(resetRegisterActions());
	}
}

export default AuthService;
