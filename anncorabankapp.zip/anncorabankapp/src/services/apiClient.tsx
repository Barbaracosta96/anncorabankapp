import {setupAPIClient} from './api';

export const api = setupAPIClient();
