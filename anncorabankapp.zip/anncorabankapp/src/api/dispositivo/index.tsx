import {setupAPIClient} from '../../services/api';
import {DispositivoProps} from '../../interfaces/register';
import {store} from '../../redux/store/';

const {user}: any = store.getState().userReducer;

const apiClient = setupAPIClient();

export const registroDispositivo = async (data: DispositivoProps) => {
	try {
		const response = await apiClient.post(`/seguranca/cadastrar-dispositivo`, data);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const gerarAutorizacao = async () => {
	try {
		const response = await apiClient.post(`/seguranca/totp/gerar-autorizacao-app`, {
			conta: user.numeroConta,
		});
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const getSecret = async (secret: string, deviceHash: string) => {
	try {
		const response = await apiClient.post(`/test/gerar-totp-code`, {
			secret: secret,
			device_hash: deviceHash,
		});
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};
