import {setupAPIClient} from '../../services/api';
import {store} from '../../redux/store/';
import {KeyType, CadastrarChavePix} from '../../interfaces/pix';

const apiClient = setupAPIClient();

export const getListaChavesPix = async () => {
	try {
		const {user}: any = store.getState().userReducer;
		const response = await apiClient.get(
			`/pix/listar/chaves/${user.numeroConta}`,
		);
		return response;
	} catch (error: any) {
		console.log(error);
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const removerChavePix = async (paramChavePix: string) => {
	try {
		const {user}: any = store.getState().userReducer;
		const contaDeletarChave = {
			data: {
				conta: `${user.numeroConta}`,
			},
		};
		const response = await apiClient.delete(
			`/pix/deletar/chave/${paramChavePix}`,
			contaDeletarChave,
		);
		return response;
	} catch (error: any) {
		console.log(error);
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const cadastrarChavePix = async (keyType: KeyType, key?: string) => {
	try {
		const {user}: any = store.getState().userReducer;
		const novaChaveData: CadastrarChavePix = {
			tipo_chave: keyType,
		};
		if (keyType === 'cpf') {
			novaChaveData.chave = key;
		} else if (keyType === 'email') {
			novaChaveData.chave = key?.replace(/\s/g, '');
		} else if (keyType === 'telefone') {
			novaChaveData.chave = `+55${key?.replace(/\D/g, '')}`;
		}
		const response = await apiClient.post(
			`/conta/${user.numeroConta}/pix`,
			novaChaveData,
		);
		return response;
	} catch (error: any) {
		console.log(error);
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const enviaCodigoConfirmacao = async (
	tipoEnvio: 'sms' | 'email',
	telefoneOuEmail: string,
) => {
	try {
		const data: any = {};
		if (tipoEnvio === 'sms') {
			data.telefone = `${telefoneOuEmail.replace(/\D/g, '')}`;
		} else {
			data.email = `${telefoneOuEmail}`;
		}
		const response = await apiClient.post(`/validacao/enviar-token`, data);
		return response;
	} catch (error: any) {
		console.error(error);
		const errorResponse = {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
		return errorResponse;
	}
};

export const validarCodigoConfirmacao = async (
	tipoEnvio: 'sms' | 'email',
	telefoneOuEmail: string,
	token: string,
) => {
	try {
		const data: any = {};
		if (tipoEnvio === 'sms') {
			data.telefone = `${telefoneOuEmail.replace(/\D/g, '')}`;
		} else {
			data.email = `${telefoneOuEmail}`;
		}
		data.token = token.replace(/\D/g, '');
		const response = await apiClient.post(`/validacao/validar-token`, data);
		return response;
	} catch (error: any) {
		console.error(error);
		const errorResponse = {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
		return errorResponse;
	}
};

export const dadosUsuarioPix = async (keyType: string, key: string) => {
	try {
		const {user}: any = store.getState().userReducer;
		let finalKey;
		if (keyType === 'cpf') {
			finalKey = key.replace(/\D/g, '');
		} else if (keyType === 'email') {
			finalKey = key?.replace(/\s/g, '');
		} else if (keyType === 'telefone') {
			finalKey = `+55${key?.replace(/\D/g, '')}`;
		} else if (keyType === 'aleatório') {
			finalKey = key.replace(/\s/g, '');
		} else if (keyType === 'cnpj') {
			finalKey = key.replace(/\D/g, '');
		}
		const response = await apiClient.get(
			`/consulta/chave/pix/${user.numeroConta}?chave=${finalKey}`,
		);
		return response;
	} catch (error: any) {
		console.error(error);
		const errorResponse = {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
		return errorResponse;
	}
};

export const pixCachOut = async (dadosEnviaPix: any) => {
	try {
		const response = await apiClient.post(`/cash-out/pix`, dadosEnviaPix);
		console.log('retornoPix', response);
		return response;
	} catch (error: any) {
		console.log(error);
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};