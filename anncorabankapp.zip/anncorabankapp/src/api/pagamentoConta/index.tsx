import {setupAPIClient} from '../../services/api';

const apiClient = setupAPIClient();

export const queryAcount = async (tipo: string, codNumber: string) => {
	codNumber = codNumber.replace(/\D/g, '');

	const dataJson = {
		codigo_barras: {
			tipo: 0,
			digitavel: `${codNumber}`,
		},
	};

	try {
		const response = await apiClient.post(
			`/pagamento-contas/consultar-conta`,
			dataJson,
		);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const reserveAmount = async (
	valor: number,
	tipo: string,
	codNumber: string,
	docCliente: string,
	dataVencimento: string,
	idAutorization: string,
) => {
	docCliente = docCliente.replace(/\D/g, '');
	const dataJsonAmount = {
		cpf_cnpj: `${docCliente}`,
		dados_conta: {
			valor: valor,
			valor_original: valor,
			valor_desconto: 0,
			valor_adicional: 0,
		},
		codigo_barras: {
			tipo: 2,
			digitavel: `${codNumber}`,
		},
		data_vencimento: `${dataVencimento}`,
		id_transacao_authorize: `${idAutorization}`,
	};

	try {
		const response = await apiClient.post(
			`pagamento-contas/reservar-saldo`,
			dataJsonAmount,
		);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const makePayment = async (idAutorization: string) => {
	try {
		const response = await apiClient.put(
			`/pagamento-contas/confirmar-pagamento/${idAutorization}`,
		);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};
