import {setupAPIClient} from '../../services/api';
import {UserDataRegister} from '../../interfaces/register';
import {store} from '../../redux/store/';

const {user}: any = store.getState().userReducer;

const apiClient = setupAPIClient();

export const registroPessoaFisica = async (data: UserDataRegister) => {
	try {
		const response = await apiClient.post(`/conta/pessoa-fisica`, data);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const registroTokenIdWall = async (token: string, cpf: string) => {
	try {
		const response = await apiClient.put(
			`/conta/pessoa-fisica/token-sdk-idwall?cpf=${cpf?.replace(/\D/g, '')}`,
			{
				token_sdk_idwall: token
			},
		);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
			message: error?.response?.data?.message,
		};
	}
};
