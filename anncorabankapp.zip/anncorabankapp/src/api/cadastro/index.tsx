import {setupAPIClient} from '../../services/api';

const apiClient = setupAPIClient();

export const regiterAccount = async (data: object) => {
	try {
		const response = await apiClient.post(`/conta/pessoa-fisica`, data);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const regiterAccountCompany = async (data: object) => {
	try {
		const response = await apiClient.post(`/conta/empresa`, data);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const sendCodeVerification = async (type: string, value: string) => {
	try {
		let data = {};
		if (type === 'email') {
			data = {
				email: value,
			};
		} else if (type === 'sms') {
			data = {
				telefone: value,
			};
		}
		const response = await apiClient.post(`/validacao/enviar-token`, data);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const verifyCode = async (
	valueToken: string,
	type: string,
	valueType: string,
) => {
	try {
		let data = {};
		if (type === 'email') {
			data = {
				email: valueType,
				token: valueToken,
			};
		} else if (type === 'sms') {
			data = {
				telefone: valueType,
				token: valueToken,
			};
		}
		const response = await apiClient.post(`/validacao/validar-token`, data);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};
