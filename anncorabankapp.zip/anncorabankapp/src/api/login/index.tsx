import {setupAPIClient} from '../../services/api';
import {useDispatch} from 'react-redux';
import {setUserData} from '../../redux/actions/userActions';

const apiClient = setupAPIClient();

export const login = async (email: string, senha: string) => {
	try {
		const data = {
			usuario: email,
			senha: senha,
		};
		const response = await apiClient.post(`/login`, data);
		console.log(response.data);
		return response;
	} catch (error: any) {
		console.log(error);
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};

export const logout = async ({navigation}: any) => {
	console.log('entrou no logout');
	const dispatch = useDispatch();
	dispatch(
		setUserData({
			id: '',
			name: '',
			email: '',
			codinstituicao: '',
			perfilid: '',
			numeroConta: '',
			tipoConta: '',
			telefone: '',
			docCliente: '',
			tipo_auth_transacao: '',
		}),
	);
	navigation.navigate('Login');
};
