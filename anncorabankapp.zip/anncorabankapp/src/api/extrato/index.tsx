import {setupAPIClient} from '../../services/api';
import {store} from '../../redux/store/';

const apiClient = setupAPIClient();

export const getExtratoByPage = async (page: number) => {
	const {user}: any = store.getState().userReducer;
	const perPage = 10;
	try {
		const response = await apiClient.get(
			`/relatorios/extrato-conta-corrente/${user.numeroConta}`,
			{
				params: {
					page: page,
					limit: perPage,
					order: 'desc',
				},
			}
		);
		return response;
	} catch (error: any) {
		return {
			error: error?.response?.status,
			data: error?.response?.data,
			status: error?.response?.status,
		};
	}
};
