import * as React from 'react';
import {useEffect} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNavigationContainerRef} from '@react-navigation/native';

import {SafeAreaProvider} from 'react-native-safe-area-context';

import {PersistGate} from 'redux-persist/es/integration/react';
import {Provider} from 'react-redux';

import IdwallSdk from '@idwall/react-native-idwall-sdk';

import {store, persistor} from './redux/store';

import Routes from './routes';

import {AuthService} from './services/AuthService';

const navigationRef = createNavigationContainerRef();

const App = () => {
	useEffect(() => {
		IdwallSdk.initialize('1f4353e5-dadb-462d-91eb-7c3c985ada57');
		if (IdwallSdk.ios) {
			IdwallSdk.ios.setupPublicKeys([
				'AHYMQP+2/KIo32qYcfqnmSn+N/K3IdSZWlqa2Zan9eY=',
				'tDilFQ4366PMdAmN/kyNiBQy24YHjuDs6Qsa6Oc/4c8=',
			]);
		}
	}, []);

	const checkToken = async () => {
		AuthService.setNavigation(navigationRef);
		const isValidToken = await AuthService.isValidToken();
		if (isValidToken) {
			AuthService.redirectToHome();
		} else {
			AuthService.redirectToInitialScreen();
		}
	};

	const checkTokenStageChange = async () => {
		AuthService.setNavigation(navigationRef);
		const tokenExpired = await AuthService.isTokenExpired();
		if (tokenExpired) {
			AuthService.resetRedux();
			AuthService.redirectToLoginScreen();
		}
	};

	const checkTokenLoop = async () => {
		const tokenExpired = await AuthService.isTokenExpired();
		if (tokenExpired) {
			AuthService.resetRedux();
			AuthService.redirectToLoginScreen();
		}
		setTimeout(() => {
			checkTokenLoop();
		}, 60000);
	};

	useEffect(() => {
		if (navigationRef.isReady()) {
			checkTokenLoop();
		}
	}, [navigationRef]);

	return (
		<Provider store={store}>
			<PersistGate loading={null} persistor={persistor}>
				<SafeAreaProvider>
					<NavigationContainer
						onReady={() => {
							try {
								if (navigationRef.isReady()) {
									checkToken();
								}
							} catch (e) {
								console.log(e);
							}
						}}
						onStateChange={() => {
							try {
								if (navigationRef.isReady()) {
									checkTokenStageChange();
								}
							} catch (e) {
								console.log(e);
							}
						}}
						ref={navigationRef}>
						<Routes />
					</NavigationContainer>
				</SafeAreaProvider>
			</PersistGate>
		</Provider>
	);
};

export default App;
