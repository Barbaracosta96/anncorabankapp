const constants = {
	// generalApiPath: 'https://apisandbox.anncora.com.br/api/v1',
	generalApiPath: 'https://mobileapi.anncora.com.br/api/v1',

	clientToken: '8c6ad500-16b1-4b80-830e-5b3a0b3fdf0d',

	// clientToken: '71ae6cde-0a99-4db8-884f-fc78cf17b718',
};

export default constants;

// generalApiPath: 'https://apisandbox.anncora.com.br/api/v1'
// generalApiPath: 'https://mobileapi.anncora.com.br/api/v1'