import * as React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import ContainerTabs from './screens/ContainerPages/ContainerTabs';
import IdWall from './screens/Registro/IdWall';

import PaginaInicial from './screens/PaginaInicial';

import LoginScreen from './screens/Login';
import Privacidade from './screens/Login/privacidade';
import Atendimento from './screens/Login/atendimento';

import AbrirConta from './screens/Registro/AbrirConta';
import Endereco from './screens/Registro/Endereco';
import Email from './screens/Registro/Email';
import Telefone from './screens/Registro/Telefone';
import Analise from './screens/Registro/Analise';
import Bloqueado from './screens/Registro/Bloqueado';
import Senha from './screens/Registro/Senha';
import PreIdWall from './screens/Registro/PreIdWall';

import Extrato from './screens/Extrato';

import MinhasChaves from './screens/Pix/MinhasChaves';
import Transferir from './screens/Pix/Transferir';
import TransferirDestino from './screens/Pix/TransferirDestino';
import TransferirConfirmar from './screens/Pix/TransferirConfirmar';
import Comprovante from './screens/Pix/Comprovante';

import Conta from './screens/Conta';

const options = {
	headerShown: false,
};

const Stack = createNativeStackNavigator();

const LoginStack = createNativeStackNavigator();

const RegisterStack = createNativeStackNavigator();

function LoginStackScreen() {
	return (
		<LoginStack.Navigator screenOptions={{...options, animation: 'slide_from_bottom'}}>
			<LoginStack.Screen name="Login" component={LoginScreen} />
			<LoginStack.Screen name="Privacidade" component={Privacidade} />
			<LoginStack.Screen name="Atendimento" component={Atendimento} />
		</LoginStack.Navigator>
	);
}

function RegisterStackScreen() {
	return (
		<RegisterStack.Navigator screenOptions={{...options}}>
			<RegisterStack.Screen name="AbrirConta" component={AbrirConta} />
			<RegisterStack.Screen name="Endereco" component={Endereco} />
			<RegisterStack.Screen name="Email" component={Email} />
			<RegisterStack.Screen name="Telefone" component={Telefone} />
			<RegisterStack.Screen name="IdWall" component={IdWall} />
			<RegisterStack.Screen name="Analise" component={Analise} />
			<RegisterStack.Screen name="Bloqueado" component={Bloqueado} />
			<RegisterStack.Screen name="Senha" component={Senha} />
			<RegisterStack.Screen name="PreIdWall" component={PreIdWall} />
		</RegisterStack.Navigator>
	);
}

const Routes = () => {
	return (
		<Stack.Navigator screenOptions={options}>
			<Stack.Group screenOptions={{ presentation: 'transparentModal' }}>
				<Stack.Screen name="PaginaInicial" component={PaginaInicial} />
				<Stack.Screen name="LoginContainer" component={LoginStackScreen} />
			</Stack.Group>
			<Stack.Group>
				<Stack.Screen name="RegisterContainer" component={RegisterStackScreen} />
			</Stack.Group>
			<Stack.Group screenOptions={{ presentation: 'modal' }}>
				<Stack.Screen name="ContainerTabs" component={ContainerTabs} />
				<Stack.Screen name="Extrato" component={Extrato} />
				<Stack.Screen name="MinhasChaves" component={MinhasChaves} />
				<Stack.Screen name="Transferir" component={Transferir} />
				<Stack.Screen name="TransferirDestino" component={TransferirDestino} />
				<Stack.Screen name="TransferirConfirmar" component={TransferirConfirmar} />
				<Stack.Screen name="Comprovante" component={Comprovante} />
				<Stack.Screen name="Conta" component={Conta} />
			</Stack.Group>
		</Stack.Navigator>
	);
};

export default Routes;
