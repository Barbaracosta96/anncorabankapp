import * as React from 'react';
import {ImageBackground, ScrollView, View} from 'react-native';

const Container = ({children, disabledScroll = false}: any) => {
	return (
		<ImageBackground
			source={require('../../assets/backgrounds/predio-gradiente.png')}
			style={{
				flex: 1,
				alignItems: 'center',
			}}>
			{disabledScroll ? (
				<View
					style={{
						flex: 1,
						// paddingTop: 20,
						// paddingBottom: 20,
					}}>
					{children}
				</View>
			) : (
				<ScrollView
					contentContainerStyle={{
						paddingTop: 20,
						flexGrow: 1,
						justifyContent: 'flex-start',
						alignItems: 'center',
						paddingBottom: 20,
					}}>
					{children}
				</ScrollView>
			)}
		</ImageBackground>
	);
};

export default Container;
