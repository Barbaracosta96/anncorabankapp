import React from 'react';
import {View, Image, Text, StyleSheet, Dimensions, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useSelector} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';
import {saudacaoDoDiaComNome} from '../../utils/texts';

const TopBar: React.FC = () => {
	const user = useSelector((state: any) => state?.userReducer?.user);
	const navigation = useNavigation<NativeStackNavigationProp<any>>();

	return (
		<View style={styles.container}>
			<View style={styles.leftContainer}>
				<View style={{flexDirection: 'column', alignItems: 'flex-start'}}>
					<Image
						source={require('../../assets/logos/logo_horizontal.png')}
						style={styles.logo}
					/>
					<Text style={styles.userName}>
						{user?.name ? saudacaoDoDiaComNome(user?.name) : '-'}
					</Text>
				</View>
			</View>
			<View style={styles.rightContainer}>
				<TouchableOpacity
					onPress={() => {
						navigation.navigate('Conta');
					}}
				>
					<Icon name="account-circle-outline" size={45} color="#b9ddf8" />
				</TouchableOpacity>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		width: Dimensions.get('window').width * 0.9,
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		marginTop: Dimensions.get('window').height * 0.03 * -1,
	},
	leftContainer: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	logo: {
		maxHeight: 40,
		maxWidth: 150,
		resizeMode: 'contain',
		marginRight: 10,
	},
	userName: {
		fontSize: 16,
		fontWeight: 'bold',
	},
	rightContainer: {
		flexDirection: 'row',
	},
});

export default TopBar;
