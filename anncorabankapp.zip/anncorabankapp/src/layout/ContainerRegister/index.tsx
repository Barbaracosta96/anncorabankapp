import * as React from 'react';
import {ScrollView} from 'react-native';

const ContainerRegister = ({children}: any) => {
	return (
		<ScrollView
			contentContainerStyle={{
				paddingTop: 20,
				flexGrow: 1,
				justifyContent: 'flex-start',
				alignItems: 'center',
				paddingBottom: 20,
				backgroundColor: '#2b2e32',
			}}>
			{children}
		</ScrollView>
	);
};

export default ContainerRegister;
