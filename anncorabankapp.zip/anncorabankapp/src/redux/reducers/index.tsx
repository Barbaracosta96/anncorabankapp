import {combineReducers} from 'redux';

import userReducer from './userReducer';
import saldoReducer from './saldoReducer';
import userRegisterReducer from './userRegisterReducer';
import authReducer from './authReducer';

const rootReducer = combineReducers({
	userReducer,
	saldoReducer,
	userRegisterReducer,
	authReducer,
});

export default rootReducer;
