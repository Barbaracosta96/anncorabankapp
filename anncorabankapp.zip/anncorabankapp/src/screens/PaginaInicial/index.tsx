import * as React from 'react';
import {
	View,
	ImageBackground,
	StyleSheet,
	Image,
	Dimensions,
} from 'react-native';

import ButtonNormal from '../../components/botoes/ButtonNormal';
import ButtonOutline from '../../components/botoes/ButtonOutline';
import FooterRegister from '../../components/FooterRegister';

const PaginaInicial: React.FC = ({navigation}: any) => {
	return (
		<View style={styles.container}>
			<ImageBackground
				source={require('../../assets/backgrounds/predio-gradiente.png')}
				style={styles.backgroundImage}>
				<View style={styles.logoContainer}>
					<Image
						source={require('../../assets/logos/logo_branca.png')}
						style={styles.logo}
					/>
				</View>

				<View style={styles.buttonRow}>
					<ButtonOutline
						onPress={() => {
							navigation.navigate('LoginContainer', {screen: 'Login'});
						}}
						text="JÁ TENHO CONTA"
					/>
					<View style={{marginLeft: 10}} />
					<ButtonNormal
						onPress={() => {
							// navigation.navigate('RegisterContainer', {
							// 	screen: 'IdWall',
							// });
							navigation.navigate('RegisterContainer', {
								screen: 'AbrirConta',
							});
						}}
						text="ABRIR CONTA"
						color="#426385"
					/>
				</View>

				<FooterRegister />
			</ImageBackground>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	backgroundImage: {
		flex: 1,
		resizeMode: 'cover',
		justifyContent: 'center',
		alignItems: 'center',
	},
	logoContainer: {
		flex: 1,
	},
	logo: {
		maxWidth: Dimensions.get('window').width * 0.7,
		height: Dimensions.get('window').height * 0.24,
		resizeMode: 'contain',
		marginTop: Dimensions.get('window').height * 0.25,
		marginBottom: Dimensions.get('window').height * 0.2,
	},
	iconRow: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignContent: 'center',
		marginBottom: 20,
		marginTop: 20,
		width: Dimensions.get('window').width * 0.4,
	},
	iconContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginLeft: Dimensions.get('window').width * 0.03,
		maxWidth: Dimensions.get('window').width * 0.8,
		marginBottom: Dimensions.get('window').height * 0.03,
	},
	iconTouch: {
		alignItems: 'center',
		marginLeft: 5,
	},
	buttonRow: {
		flexDirection: 'row',
	},
	buttonJaTenhoConta: {
		borderWidth: 2,
		borderColor: 'white',
		paddingHorizontal: 20,
		paddingVertical: 10,
		marginRight: 10,
	},
	buttonTextJaTenhoConta: {
		color: 'white',
	},
	buttonAbrirConta: {
		backgroundColor: '#426385',
		paddingHorizontal: 20,
		paddingVertical: 10,
	},
	buttonTextAbrirConta: {
		color: 'white',
	},
});

export default PaginaInicial;
