import React, {useState} from 'react';
import {View, Text, StyleSheet, Alert} from 'react-native';

import {useDispatch} from 'react-redux';

import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';
import {CommonActions} from '@react-navigation/native';

import Icon from 'react-native-vector-icons/FontAwesome';

import IdwallSdk, {
	IdwallFlowType,
	IdwallDocumentType,
	IdwallDocumentOption,
} from '@idwall/react-native-idwall-sdk';

import ContainerRegister from '../../../layout/ContainerRegister';

import ButtonDefault from '../../../components/ButtonDefault';
import Loading from '../../../components/Loading';

import {login} from '../../../api/login';
import {registroTokenIdWall} from '../../../api/registro';

import {storeJWT as storeJWTRedux} from '../../../redux/actions/authActions';

const PreIdWall: React.FC = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const dispatch = useDispatch();
	const params: any = useRoute().params;
	const [isLoading, setIsLoading] = useState(false);

	const callIdWall = async () => {
		try {
			const token: string = await IdwallSdk.startFlow(
				IdwallFlowType.COMPLETE,
				[IdwallDocumentType.RG, IdwallDocumentType.CNH],
				[IdwallDocumentOption.PRINTED],
			);

			try {
				setIsLoading(true);
				const response = await login(params.email, params.password);
				const cpf = response?.data?.usuario_conta?.numero_documento;
				dispatch(storeJWTRedux(response.data.token));
				await registroTokenIdWall(token, cpf);
				setIsLoading(false);
				navigation.dispatch(
					CommonActions.reset({
						index: 1,
						routes: [
							{
								name: 'PaginaInicial',
							},
							{
								name: 'RegisterContainer',
								params: {
									screen: 'Analise',
								},
							},
						],
					}),
				);
			} catch (error) {
				setIsLoading(false);
				console.log('Erro', error);
			} finally {
				setIsLoading(false);
			}
			console.log('Fluxo de documentos com sucesso ::', token);
		} catch (error) {
			Alert.alert('Alerta', 'Não foi possível validar seus documentos.');
			console.log('Erro::', error);
		}
	};

	return (
		<ContainerRegister>
			<View style={styles.container}>
				<Icon name="user" size={50} color="#3498db" />
				<Text style={styles.title}>Estamos quase terminando! 🙂</Text>
				<Text style={styles.title}>
					Agora precisamos da{'\n'}indentificação dos{'\n'}seus documentos 📄
				</Text>
				<Text style={styles.subtitle}>
					Para isso, você precisará de:{'\n'}- RG ou CNH;{'\n'}- Assim como uma
					selfie.{'\n'}
				</Text>
				<ButtonDefault
					onPress={() => callIdWall()}
					title={'CONTINUAR'}
					iconName={'send'}
				/>
			</View>
			<Loading visible={isLoading} />
		</ContainerRegister>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		marginVertical: 5,
		paddingHorizontal: 20,
		textAlign: 'center',
	},
	subtitle: {
		marginVertical: 5,
		fontSize: 18,
		color: '#888',
		textAlign: 'center',
	},
});

export default PreIdWall;
