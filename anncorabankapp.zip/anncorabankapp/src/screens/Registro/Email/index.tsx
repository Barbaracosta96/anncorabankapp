import React, {useState, useEffect} from 'react';
import {
	View,
	Text,
	StyleSheet,
	TextInput,
	Dimensions,
	ScrollView,
	KeyboardAvoidingView,
	Platform,
	Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

import ContainerRegister from '../../../layout/ContainerRegister';
import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';
import {
	enviaCodigoConfirmacao,
	validarCodigoConfirmacao,
} from '../../../api/pix';
import {isValidEmail} from '../../../utils/validationMask';

const Email = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const params = useRoute()?.params || {};

	const [email, setEmail] = useState('');
	const [codeSent, setCodeSent] = useState(false);
	const [btCodeEnabled, setBtCodeEnabled] = useState(false);
	const [codes, setCodes] = useState(['', '', '', '', '', '']);
	const inputRefs = Array(6).fill(React.createRef());

	const handleSendCode = async () => {
		if (email && isValidEmail(email)) {
			try {
				setBtCodeEnabled(true);
				await enviaCodigoConfirmacao('email', email);
				setBtCodeEnabled(false);
			} catch (e) {
				setBtCodeEnabled(false);
				console.log(e);
			}
			setCodeSent(true);
		} else {
			Alert.alert('Erro', 'Por favor, insira seu e-mail.');
		}
	};

	const verifyCode = async () => {
		const code = codes.join('');
		if (code.length === 6) {
			try {
				setBtCodeEnabled(true);
				const result = await validarCodigoConfirmacao('email', email, code);
				setBtCodeEnabled(false);
				if (result.status === 400) {
					await enviaCodigoConfirmacao('email', email);
					Alert.alert('Alerta', 'Código inválido');
					return;
				}
				if (result.status === 422) {
					await enviaCodigoConfirmacao('email', email);
					Alert.alert('Alerta', 'Código expirado, enviamos outro código.');
					return;
				}
				if (result.status === 200) {
					navigation.navigate('RegisterContainer', {
						screen: 'Telefone',
						params: {
							...params,
							email,
						},
					});
				}
			} catch (e) {
				console.log(e);
			}
		} else {
			Alert.alert('Erro', 'Por favor, insira o código de confirmação.');
		}
	};

	const handleCodeInput = (text: string, index: number) => {
		const newCodes = [...codes];
		newCodes[index] = text;
		setCodes(newCodes);

		if (text.length === 1 && index < 5) {
			inputRefs[index + 1].focus();
		}
	};

	return (
		<ContainerRegister>
			<View style={styles.header}>
				<HeaderTitle title="E-mail" showSeparator />
			</View>
			<ScrollView
				contentContainerStyle={styles.content}
				keyboardShouldPersistTaps="handled">
				<KeyboardAvoidingView
					style={styles.formContainer}
					behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
					<View style={styles.iconContainer}>
						<Icon name="mail-outline" size={40} color="#4e7a98" />
					</View>
					<Text style={styles.title}>
						{codeSent
							? 'Enviamos um código para seu e-mail'
							: 'Digite seu e-mail'}
					</Text>
					{codeSent ? (
						<View style={styles.codeInputContainer}>
							{codes.map((code, index) => (
								<TextInput
									key={index}
									value={code}
									onChangeText={text => handleCodeInput(text, index)}
									placeholder="0"
									placeholderTextColor="gray"
									keyboardType="numeric"
									style={styles.codeInput}
									ref={input => (inputRefs[index] = input)}
									maxLength={1}
								/>
							))}
						</View>
					) : (
						<TextInput
							value={email}
							onChangeText={text => setEmail(text)}
							placeholder="Seu e-mail"
							placeholderTextColor="gray"
							keyboardType="email-address"
							style={styles.input}
						/>
					)}
					<ButtonDefault
						disabled={btCodeEnabled}
						onPress={codeSent ? verifyCode : handleSendCode}
						title={codeSent ? 'Verificar Código' : 'Enviar Código'}
						iconName={codeSent ? 'arrow-forward-circle-outline' : 'send'}
					/>
				</KeyboardAvoidingView>
			</ScrollView>
		</ContainerRegister>
	);
};

const styles = StyleSheet.create({
	header: {
		width: Dimensions.get('window').width,
	},
	content: {
		flexGrow: 1,
		alignItems: 'center',
		backgroundColor: '#2b2e32',
		paddingHorizontal: 20,
	},
	formContainer: {
		flex: 1,
		alignItems: 'center',
	},
	iconContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginBottom: 10,
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#4e7a98',
		marginBottom: 10,
		textAlign: 'center',
	},
	subTitle: {
		fontSize: 16,
		color: '#75b7e4',
		paddingHorizontal: 20,
		textAlign: 'center',
		fontStyle: 'italic',
		marginBottom: 20,
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 6,
		marginBottom: 8,
		borderRadius: 8,
		color: 'white',
		width: Dimensions.get('window').width * 0.8,
	},
	codeInputContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		width: Dimensions.get('window').width * 0.8,
	},
	codeInput: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 6,
		marginBottom: 8,
		borderRadius: 8,
		color: 'white',
		width: '15%',
		textAlign: 'center',
	},
});

export default Email;
