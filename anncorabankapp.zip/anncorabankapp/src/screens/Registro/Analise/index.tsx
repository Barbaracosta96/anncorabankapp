import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

import ContainerRegister from '../../../layout/ContainerRegister';

const Analise: React.FC = () => {
	return (
		<ContainerRegister>
			<View style={styles.container}>
				<Icon name="user" size={50} color="#3498db" />
				<Text style={styles.title}>Agradecemos seu cadastro!</Text>
				<Text style={styles.title}>Sua conta está em análise! 🔍</Text>
				<Text style={styles.subtitle}>
					A verificação pode lever alguns dias.
					Você pode fazer login usando seu e-mail e senha, para acompanhar o
					andamento do seu cadastro.
				</Text>
			</View>
		</ContainerRegister>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	title: {
		fontSize: 24,
		fontWeight: 'bold',
		marginVertical: 5,
		textAlign: 'center',
	},
	subtitle: {
		marginVertical: 5,
		fontSize: 18,
		color: '#888',
		textAlign: 'center',
		paddingHorizontal: 50,
	},
});

export default Analise;
