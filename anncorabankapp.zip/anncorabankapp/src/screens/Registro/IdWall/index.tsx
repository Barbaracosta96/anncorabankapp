import * as React from 'react';
import { useEffect } from 'react';
import {View, Text} from 'react-native';

import IdwallSdk, {
  IdwallFlowType,
  IdwallSendType,
  IdwallDocumentType,
  IdwallDocumentSide,
  IdwallDocumentOption,
} from '@idwall/react-native-idwall-sdk';

const IdWall: React.FC = () => {
	useEffect(() => {
		IdwallSdk.startFlow(
			IdwallFlowType.COMPLETE, //tipo de fluxo
			[IdwallDocumentType.RG, IdwallDocumentType.CNH],// lista de documentos desejados para o fluxo
			[IdwallDocumentOption.PRINTED, IdwallDocumentOption.DIGITAL] // lista de formas de envio
		).then((token: string) => console.log('Fluxo de documentos com sucesso ::', token))
			.catch(error => console.log("Erro::" + error));
	}, []);

	return (
		null
	);
}

export default IdWall;
