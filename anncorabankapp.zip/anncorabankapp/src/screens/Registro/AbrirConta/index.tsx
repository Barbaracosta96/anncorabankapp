import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Dimensions,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack/lib/typescript/src/types';

import ContainerRegister from '../../../layout/ContainerRegister';
import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';

import { cpfMask, birthDateMask } from '../../../utils/inputMask';
import {
  isValidCpf,
  isValidDate,
  isValidFullName,
} from '../../../utils/validationMask';

const AbrirConta = () => {
  const navigation = useNavigation<NativeStackNavigationProp<any>>();
  const [formData, setFormData] = useState({
    name: '',
    cpf: '',
    birthDate: '',
    motherName: '',
  });
  const [errors, setErrors] = useState({
    cpf: '',
    name: '',
    birthDate: '',
    motherName: '',
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData({
      ...formData,
      [field]: value,
    });
    setErrors({
      ...errors,
      [field]: '',
    });
  };

  const handleNextPage = () => {
    const { cpf, name, birthDate, motherName } = formData;
    const newErrors = {
      cpf: !isValidCpf(cpf) ? 'CPF inválido.' : '',
      name: !isValidFullName(name) ? 'Nome inválido, digite seu nome completo.' : '',
      birthDate: !isValidDate(birthDate).valid ? isValidDate(birthDate).message : '',
      motherName: !isValidFullName(motherName) ? 'Nome inválido, digite o nome completo da sua mãe.' : '',
    };

    setErrors(newErrors);

    if (Object.values(newErrors).every((error) => !error)) {
      navigation.navigate('RegisterContainer', {
        screen: 'Endereco',
				params: {
					...formData
				},
      });
    }
  };

  useEffect(() => {
    const errorTimer = setTimeout(() => {
      setErrors({
        cpf: '',
        name: '',
        birthDate: '',
        motherName: '',
      });
    }, 5000);

    return () => clearTimeout(errorTimer);
  }, [errors]);

  return (
    <ContainerRegister>
      <View style={styles.header}>
        <HeaderTitle title="Cadastro" showSeparator />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <KeyboardAvoidingView
          style={styles.formContainer}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={styles.iconContainer}>
            <Icon name="card-outline" size={40} color="white" />
          </View>
          <Text style={styles.title}>Vamos Começar?</Text>
          <Text style={styles.subTitle}>
            Para abrir sua conta, precisamos de algumas informações.
          </Text>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>CPF</Text>
            <TextInput
              value={formData.cpf}
              onChangeText={(text) => handleInputChange('cpf', cpfMask(text))}
              placeholder="000.000.000-00"
              placeholderTextColor="gray"
              keyboardType="numeric"
              style={styles.input}
            />
            {errors.cpf && <Text style={styles.error}>{errors.cpf}</Text>}
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Nome Completo</Text>
            <TextInput
              value={formData.name}
              onChangeText={(text) => handleInputChange('name', text)}
              placeholder="Seu nome completo"
              placeholderTextColor="gray"
              style={styles.input}
            />
            {errors.name && <Text style={styles.error}>{errors.name}</Text>}
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Data Nascimento</Text>
            <TextInput
              value={formData.birthDate}
              onChangeText={(text) =>
                handleInputChange('birthDate', birthDateMask(text))
              }
              placeholder="00/00/0000"
              placeholderTextColor="gray"
              keyboardType="numeric"
              style={styles.input}
            />
            {errors.birthDate && <Text style={styles.error}>{errors.birthDate}</Text>}
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Nome da sua Mãe</Text>
            <TextInput
              value={formData.motherName}
              onChangeText={(text) => handleInputChange('motherName', text)}
              placeholder="Nome da sua mãe"
              placeholderTextColor="gray"
              style={styles.input}
            />
            {errors.motherName && <Text style={styles.error}>{errors.motherName}</Text>}
          </View>
          <ButtonDefault
            onPress={() => {
              handleNextPage();
            }}
            title="CONTINUAR"
            iconName="arrow-forward-circle-outline"
          />
        </KeyboardAvoidingView>
      </ScrollView>
    </ContainerRegister>
  );
};

const styles = StyleSheet.create({
	header: {
		width: Dimensions.get('window').width,
	},
	content: {
		flexGrow: 1,
		alignItems: 'center',
		backgroundColor: '#2b2e32',
		paddingHorizontal: 20,
	},
	formContainer: {
		flex: 1,
		alignItems: 'center',
	},
	iconContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginBottom: 10,
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#4e7a98',
		marginBottom: 10,
		textAlign: 'center',
	},
	subTitle: {
		fontSize: 16,
		color: '#75b7e4',
		paddingHorizontal: 20,
		textAlign: 'center',
		fontStyle: 'italic',
		marginBottom: 20,
	},
	inputContainer: {
		width: Dimensions.get('window').width * 0.8,
		marginBottom: 20,
	},
	label: {
		color: 'white',
		fontSize: 16,
		marginBottom: 6,
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 6,
		marginBottom: 8,
		borderRadius: 8,
		color: 'white',
	},
	error: {
    color: '#f73378',
  },
});

export default AbrirConta;
