import React, {useState, useEffect} from 'react';
import {
	View,
	Text,
	StyleSheet,
	TextInput,
	Dimensions,
	ScrollView,
	KeyboardAvoidingView,
	Platform,
	Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';
import {CommonActions} from '@react-navigation/native';

import moment from 'moment';

import ContainerRegister from '../../../layout/ContainerRegister';
import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';

import {isStrongerKey} from '../../../utils/validationMask';

import {registroPessoaFisica} from '../../../api/registro';

import {UserDataRegister} from '../../../interfaces/register';

const Senha = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const params: any = useRoute().params;
	const [formData, setFormData] = useState({
		password: '',
		confirmPassword: '',
	});
	const [errors, setErrors] = useState({
		password: '',
		confirmPassword: '',
	});
	const [btCodeEnabled, setBtCodeEnabled] = useState(false);

	const handleInputChange = (field: string, value: string) => {
		setFormData({
			...formData,
			[field]: value,
		});
		setErrors({
			...errors,
			[field]: '',
		});
	};

	const handleNextPage = async () => {
		const {password, confirmPassword} = formData;
		const newErrors = {
			password: !isStrongerKey(password)
				? 'Sua senha deve conter no mínimo 10 caracteres, sendo ' +
				  'pelo menos uma letra maiúscula, uma minúscula, um número ' +
				  'e um caractere especial.'
				: '',
			confirmPassword:
				password !== confirmPassword ? 'As senhas não coincidem.' : '',
		};

		setErrors(newErrors);

		if (Object.values(newErrors).every(error => !error)) {
			try {
				setBtCodeEnabled(true);
				const data: UserDataRegister = {
					usuario: {
						email: params?.email || '',
						senha: password || '',
					},
					nome_completo: params?.name || '',
					cpf: params?.cpf || '',
					telefone: (params?.phone || '').replace(/\D/g, ''),
					nome_mae: params?.motherName || '',
					data_nascimento: params?.birthDate
						? moment(params.birthDate, 'DD/MM/YYYY').format('DD-MM-YYYY')
						: '',
					endereco: {
						cep:
							params?.cep
								?.replace(/\D/g, '')
								?.replace(/(\d{2})(\d{3})(\d{3})/, '$1.$2-$3') || '',
						logradouro: `${params?.street || ''},${params?.number || ''},${
							params?.district || ''
						}`,
						cidade: params?.city || '',
						sigla_uf: params?.state || '',
					},
				};

				const response: any = await registroPessoaFisica(data);
				setBtCodeEnabled(false);
				console.log('response', response);

				if (response?.data?.status === 400) {
					Alert.alert(
						'Alerta',
						response?.data?.message
							? response?.data?.message.replace('Error:', '')
							: 'Ocorreu um erro no cadastro tente novamente.',
					);
					return;
				}

				if (response?.status === 201) {
					navigation.dispatch(
						CommonActions.reset({
							index: 1,
							routes: [
								{name: 'PaginaInicial'},
								{
									name: 'RegisterContainer',
									params: {
										screen: 'PreIdWall',
										params: {
											...formData,
											...params,
										},
									},
								},
							],
						}),
					);
				} else {
					Alert.alert('Erro', 'Ocorreu um erro no cadastro tente novamente.');
				}
			} catch (error: any) {
				Alert.alert('Erro', 'Ocorreu um erro no cadastro tente novamente.');
				setBtCodeEnabled(false);
				console.log(error);
			} finally {
				setBtCodeEnabled(false);
			}
		}
	};

	useEffect(() => {
		const errorTimer = setTimeout(() => {
			setErrors({
				password: '',
				confirmPassword: '',
			});
		}, 5000);

		return () => clearTimeout(errorTimer);
	}, [errors]);

	return (
		<ContainerRegister>
			<View style={styles.header}>
				<HeaderTitle title="Cadastro" showSeparator />
			</View>
			<ScrollView contentContainerStyle={styles.content}>
				<KeyboardAvoidingView
					style={styles.formContainer}
					behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
					<View style={styles.iconContainer}>
						<Icon name="key-outline" size={40} color="white" />
					</View>
					<Text style={styles.title}>Digite a sua senha</Text>
					<Text style={styles.subTitle}>
						Digite sua senha abaixo para continuar com o cadastro.
					</Text>

					<View style={styles.inputContainer}>
						<Text style={styles.label}>Senha</Text>
						<TextInput
							value={formData.password}
							onChangeText={text => handleInputChange('password', text)}
							placeholder="Digite sua senha"
							placeholderTextColor="gray"
							secureTextEntry
							style={styles.input}
						/>
						{errors.password && (
							<Text style={styles.error}>{errors.password}</Text>
						)}
					</View>
					<View style={styles.inputContainer}>
						<Text style={styles.label}>Confirme sua Senha</Text>
						<TextInput
							value={formData.confirmPassword}
							onChangeText={text => handleInputChange('confirmPassword', text)}
							placeholder="Confirme sua senha"
							placeholderTextColor="gray"
							secureTextEntry
							style={styles.input}
						/>
						{errors.confirmPassword && (
							<Text style={styles.error}>{errors.confirmPassword}</Text>
						)}
					</View>
					<ButtonDefault
						disabled={btCodeEnabled}
						onPress={() => {
							handleNextPage();
						}}
						title="CONTINUAR"
						iconName="arrow-forward-circle-outline"
					/>
				</KeyboardAvoidingView>
			</ScrollView>
		</ContainerRegister>
	);
};

const styles = StyleSheet.create({
	header: {
		width: Dimensions.get('window').width,
	},
	content: {
		flexGrow: 1,
		alignItems: 'center',
		backgroundColor: '#2b2e32',
		paddingHorizontal: 20,
	},
	formContainer: {
		flex: 1,
		alignItems: 'center',
	},
	iconContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginBottom: 10,
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#4e7a98',
		marginBottom: 10,
		textAlign: 'center',
	},
	subTitle: {
		fontSize: 16,
		color: '#75b7e4',
		paddingHorizontal: 20,
		textAlign: 'center',
		fontStyle: 'italic',
		marginBottom: 20,
	},
	inputContainer: {
		width: Dimensions.get('window').width * 0.8,
		marginBottom: 20,
	},
	label: {
		color: 'white',
		fontSize: 16,
		marginBottom: 6,
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 6,
		marginBottom: 8,
		borderRadius: 8,
		color: 'white',
	},
	error: {
		color: '#f73378',
	},
});

export default Senha;
