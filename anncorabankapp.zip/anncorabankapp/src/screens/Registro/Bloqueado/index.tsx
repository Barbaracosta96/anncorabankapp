import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ContainerRegister from '../../../layout/ContainerRegister';

const Bloqueado: React.FC = () => {
	return (
		<ContainerRegister>
			<View style={styles.container}>
				<Icon name="block-flipped" size={50} color="#3498db" />
				<Text style={styles.title}>Não foi possível validar{'\n'}sua conta.</Text>
				<Text style={styles.subtitle}>
					Para mais detalhes entre em{'\n'}contato com o suporte.
				</Text>
			</View>
		</ContainerRegister>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	title: {
		fontSize: 24,
		fontWeight: 'bold',
		marginVertical: 5,
		textAlign: 'center',
	},
	subtitle: {
		marginVertical: 5,
		fontSize: 18,
		color: '#888',
		textAlign: 'center',
	},
});

export default Bloqueado;
