import React, {useEffect, useState} from 'react';
import {
	View,
	Text,
	StyleSheet,
	TextInput,
	Dimensions,
	ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';
import {Picker} from '@react-native-picker/picker';

import ContainerRegister from '../../../layout/ContainerRegister';
import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';

import {getAddressByCep} from '../../../api/endereco';

import {cepMask} from '../../../utils/inputMask';

const brazilianStates = [
	'AC',
	'AL',
	'AM',
	'AP',
	'BA',
	'CE',
	'DF',
	'ES',
	'GO',
	'MA',
	'MG',
	'MS',
	'MT',
	'PA',
	'PB',
	'PE',
	'PI',
	'PR',
	'RJ',
	'RN',
	'RO',
	'RR',
	'RS',
	'SC',
	'SE',
	'SP',
	'TO',
];

const brazilianStatesList = [
	{ acronym: 'AC', name: 'Acre' },
	{ acronym: 'AL', name: 'Alagoas' },
	{ acronym: 'AM', name: 'Amazonas' },
	{ acronym: 'AP', name: 'Amapá' },
	{ acronym: 'BA', name: 'Bahia' },
	{ acronym: 'CE', name: 'Ceará' },
	{ acronym: 'DF', name: 'Distrito Federal' },
	{ acronym: 'ES', name: 'Espírito Santo' },
	{ acronym: 'GO', name: 'Goiás' },
	{ acronym: 'MA', name: 'Maranhão' },
	{ acronym: 'MG', name: 'Minas Gerais' },
	{ acronym: 'MS', name: 'Mato Grosso do Sul' },
	{ acronym: 'MT', name: 'Mato Grosso' },
	{ acronym: 'PA', name: 'Pará' },
	{ acronym: 'PB', name: 'Paraíba' },
	{ acronym: 'PE', name: 'Pernambuco' },
	{ acronym: 'PI', name: 'Piauí' },
	{ acronym: 'PR', name: 'Paraná' },
	{ acronym: 'RJ', name: 'Rio de Janeiro' },
	{ acronym: 'RN', name: 'Rio Grande do Norte' },
	{ acronym: 'RO', name: 'Rondônia' },
	{ acronym: 'RR', name: 'Roraima' },
	{ acronym: 'RS', name: 'Rio Grande do Sul' },
	{ acronym: 'SC', name: 'Santa Catarina' },
	{ acronym: 'SE', name: 'Sergipe' },
	{ acronym: 'SP', name: 'São Paulo' },
	{ acronym: 'TO', name: 'Tocantins' },
];

function getStateName(acronym: string): string | undefined {
  const state = brazilianStatesList.find(state => state.acronym === acronym.toUpperCase());
  return state?.name;
}

const Endereco = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const params = useRoute()?.params || {};

	const [formData, setFormData] = useState({
		cep: '',
		street: '',
		number: '',
		complement: '',
		district: '',
		city: '',
		state: '',
	});
	const [errors, setErrors] = useState({
		cep: '',
		street: '',
		number: '',
		city: '',
		state: '',
	});

	const handleInputChange = (field: string, value: string) => {
		setFormData({
			...formData,
			[field]: value,
		});
		setErrors({
			...errors,
			[field]: '',
		});
	};

	useEffect(() => {
		if (formData.cep.length === 9) {
			getAddressByCep(formData.cep.replace(/\D/g, ''))
				.then((response: any) => {
					const {logradouro, complemento, bairro, localidade, uf} =
						response?.data || {};
					setFormData({
						...formData,
						street: logradouro || '',
						complement: complemento || '',
						district: bairro || '',
						city: localidade || '',
						state: uf || '',
					});
				})
				.catch(error => {
					console.log(error);
				});
		}
	}, [formData.cep]);

	const handleNextPage = () => {
		const {cep, street, number, city, state} = formData;
		const newErrors = {
			cep: cep.length !== 9 ? 'CEP inválido.' : '',
			street: street.length < 3 ? 'Rua inválida.' : '',
			number: number.length === 0 ? 'Número inválido.' : '',
			city: city.length < 3 ? 'Cidade inválida.' : '',
			state:
				state.length !== 2 || !isBrazilianState(state) ? 'UF inválida.' : '',
		};

		setErrors(newErrors);

		if (Object.values(newErrors).every(error => !error)) {
			navigation.navigate('RegisterContainer', {
				screen: 'Email',
				params: {
					...params,
					...formData,
				},
			});
		}
	};

	const isBrazilianState = (state: string) => {
		return brazilianStates.includes(state);
	};

	return (
		<ContainerRegister>
			<View style={styles.header}>
				<HeaderTitle title="Endereço" showSeparator />
			</View>
			<ScrollView contentContainerStyle={styles.content}>
				<View style={styles.iconContainer}>
					<Icon name="location-outline" size={40} color="#4e7a98" />
				</View>
				<Text style={styles.title}>Informe seu endereço</Text>
				<Text style={styles.subTitle}>
					Preencha os campos abaixo com as informações do seu endereço.
				</Text>
				<View style={styles.inputContainer}>
					<Text style={styles.label}>CEP</Text>
					<TextInput
						value={formData.cep}
						onChangeText={text => handleInputChange('cep', cepMask(text))}
						placeholder="00000-000"
						placeholderTextColor="gray"
						keyboardType="numeric"
						style={[styles.input, errors.cep ? styles.inputError : {}]}
					/>
					{errors.cep && <Text style={styles.error}>{errors.cep}</Text>}
				</View>
				<View style={styles.inputContainer}>
					<Text style={styles.label}>Rua</Text>
					<TextInput
						value={formData.street}
						onChangeText={text => handleInputChange('street', text)}
						placeholder="Nome da rua"
						placeholderTextColor="gray"
						style={[styles.input, errors.street ? styles.inputError : {}]}
					/>
					{errors.street && <Text style={styles.error}>{errors.street}</Text>}
				</View>
				<View style={styles.inputContainer}>
					<Text style={styles.label}>Número</Text>
					<TextInput
						value={formData.number}
						onChangeText={text => handleInputChange('number', text)}
						placeholder="Número da residência"
						placeholderTextColor="gray"
						keyboardType="numeric"
						style={[styles.input, errors.number ? styles.inputError : {}]}
					/>
					{errors.number && <Text style={styles.error}>{errors.number}</Text>}
				</View>
				<View style={styles.inputContainer}>
					<Text style={styles.label}>Complemento</Text>
					<TextInput
						value={formData.complement}
						onChangeText={text => handleInputChange('complement', text)}
						placeholder="Complemento (opcional)"
						placeholderTextColor="gray"
						style={styles.input}
					/>
				</View>
				<View style={styles.inputContainer}>
					<Text style={styles.label}>Cidade</Text>
					<TextInput
						value={formData.city}
						onChangeText={text => handleInputChange('city', text)}
						placeholder="Cidade"
						placeholderTextColor="gray"
						style={[styles.input, errors.city ? styles.inputError : {}]}
					/>
					{errors.city && <Text style={styles.error}>{errors.city}</Text>}
				</View>
				<View style={styles.inputContainer}>
					<Text style={styles.label}>Estado (UF)</Text>
					<Picker
						selectedValue={formData.state}
						style={[
							styles.input,
							styles.picker,
							errors.state ? styles.inputError : {},
						]}
						onValueChange={(itemValue: any) =>
							handleInputChange('state', itemValue)
						}>
						{brazilianStates.map(state => (
							<Picker.Item key={state} label={getStateName(state)} value={state} />
						))}
					</Picker>
					{errors.state && <Text style={styles.error}>{errors.state}</Text>}
				</View>
				<ButtonDefault
					onPress={() => {
						handleNextPage();
					}}
					title="CONTINUAR"
					iconName="arrow-forward-circle-outline"
				/>
			</ScrollView>
		</ContainerRegister>
	);
};

const styles = StyleSheet.create({
	header: {
		width: Dimensions.get('window').width,
	},
	content: {
		flexGrow: 1,
		alignItems: 'center',
		backgroundColor: '#2b2e32',
		paddingVertical: 20,
		paddingHorizontal: 20,
	},
	iconContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginBottom: 10,
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#4e7a98',
		marginBottom: 10,
		textAlign: 'center',
	},
	subTitle: {
		fontSize: 16,
		color: '#75b7e4',
		paddingHorizontal: 20,
		textAlign: 'center',
		fontStyle: 'italic',
		marginBottom: 20,
	},
	inputContainer: {
		width: Dimensions.get('window').width * 0.8,
		marginBottom: 20,
	},
	label: {
		color: 'white',
		fontSize: 16,
		marginBottom: 6,
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 6,
		marginBottom: 8,
		borderRadius: 8,
		color: 'white',
	},
	inputError: {
		borderColor: '#c60d0d',
	},
	picker: {
		height: 50,
		color: 'white',
	},
	error: {
		color: '#c60d0d',
	},
});

export default Endereco;
