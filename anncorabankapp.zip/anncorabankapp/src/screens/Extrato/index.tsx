import * as React from 'react';
import {useState, useEffect} from 'react';
import {StyleSheet, Text} from 'react-native';
import HeaderTitle from '../../components/HeaderTitle';
import Loading from '../../components/Loading';
import Container from '../../layout/Container';

import FiltroExtrato from './FiltroExtrato';

import {getExtratoByPage} from '../../api/extrato';

const Extract: React.FC = () => {
	const [listFundosGlobal, setListFundosGlobal] = useState<any>([]);
	const [page, setPage] = useState(1);
	const [loading, setLoading] = useState(false);
	const [showMore, setShowMore] = useState(false);

	useEffect(() => {
		const getExtratoByPageApi = async (page: number) => {
			if (page === 1) {
				setLoading(true);
			} else {
				setShowMore(true);
			}
			const response = await getExtratoByPage(page);
			setShowMore(false);
			setLoading(false);
			setListFundosGlobal([
				...listFundosGlobal,
				...(response?.data?.data ?? []),
			]);
		};
		try {
			getExtratoByPageApi(page);
		} catch (error) {
			setLoading(false);
			setShowMore(false);
			console.log(error);
		}
	}, [page]);

	const loadMoreData = () => {
		setPage(page + 1);
	};

	return (
		<Container disabledScroll={true}>
			<HeaderTitle title="Extrato" marginTop={16} />
			{listFundosGlobal.length > 0 ? (
				<FiltroExtrato
					listFundosGlobal={listFundosGlobal}
					loadMoreData={() => loadMoreData()}
					showMore={showMore ? true : false}
				/>
			) : (
				<>
					{!loading && <Text style={styles.noText}>Nenhum histórico...</Text>}
				</>
			)}
			{showMore && <Text style={styles.loading}>Carregando...</Text>}
			<Loading visible={loading} />
		</Container>
	);
};

const styles = StyleSheet.create({
	noText: {
		fontSize: 20,
		fontStyle: 'italic',
		color: 'white',
		flex: 1,
		textAlign: 'center',
	},
	loading: {
		textAlign: 'center',
		fontSize: 20,
	},
});

export default Extract;
