import * as React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, FlatList} from 'react-native';
// @ts-ignore
import ArrowIcon from 'react-native-vector-icons/FontAwesome6';
import {convertFloatToCurrency} from '../../../utils/moneyMask';
import {format} from 'date-fns';
import ptBR from 'date-fns/locale/pt-BR';

interface Transaction {
	id: number;
	agencia: string;
	conta_corrente: string;
	tipo_transacao: string;
	nome: string;
	sigla: string;
	valor: number;
	data: string;
	created_at: string;
}

interface PropsExtrat {
	data: Transaction;
}

const styles = StyleSheet.create({
	Container: {
		width: '100%',
		flexDirection: 'column',
		marginTop: -15,
	},
	cardNomeMes: {
		marginTop: 10,
		backgroundColor: '#26313c',
		paddingLeft: 20,
		height: 52,
		display: 'flex',
		justifyContent: 'center',
	},
	titleMes: {
		color: '#FFF',
		fontSize: 18,
		fontWeight: 'bold',
	},
	containerDia: {
		paddingLeft: 40,
		height: 40,
		display: 'flex',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
	},
	titleDia: {
		color: '#FFF',
		fontSize: 14,
		paddingLeft: 50,
	},
	dividerLinha: {
		width: '80%',
		backgroundColor: '#000',
		height: 1,
	},
	containerDadosExtrato: {
		display: 'flex',
		flexDirection: 'column',
		paddingLeft: 40,
	},
	detalhesExtrato: {
		display: 'flex',
		flexDirection: 'row',
		alignItems: 'center',
	},
	cardEsquedo: {
		paddingRight: 10,
	},
	cardDireito: {
		display: 'flex',
		flexDirection: 'column',
		maxWidth: '90%',
	},
	titleTipoGasto: {
		color: 'white',
		fontStyle: 'italic',
		fontSize: 12,
	},
	titleTpo: {
		color: '#FFF',
		fontSize: 14,
		fontWeight: 'bold',
	},
	textoValor: {
		color: '#9dbbd2',
		fontSize: 16,
		fontWeight: 'bold',
	},
	textoValorDebito: {
		color: '#d29d9d',
		fontSize: 16,
		fontWeight: 'bold',
	},
	containeRecebeDados: {
		display: 'flex',
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
	},
});

function ListaExtrato({data}: PropsExtrat) {
	const iconColor = '#fff';
	return (
		<View>
			<View style={styles.Container}>
				<View style={styles.containerDadosExtrato}>
					<View style={{height: 20}} />
					<TouchableOpacity style={styles.containeRecebeDados}>
						<View style={styles.detalhesExtrato}>
							<View style={styles.cardEsquedo}>
								{data.sigla == 'D' && (
									<ArrowIcon
										name="circle-arrow-down"
										size={20}
										color={'#d29d9d'}
									/>
								)}
								{data.sigla == 'C' && (
									<ArrowIcon
										name="circle-arrow-up"
										size={20}
										color={'#9dbbd2'}
									/>
								)}
							</View>
							<View style={styles.cardDireito}>
								<Text style={styles.titleTpo}>Debito de Cartão</Text>
								<Text numberOfLines={2} ellipsizeMode="tail">
									{data.nome}
								</Text>
								{data.sigla == 'D' && (
									<Text style={styles.textoValorDebito}>
										{convertFloatToCurrency(data.valor)}
									</Text>
								)}
								{data.sigla == 'C' && (
									<Text style={styles.textoValor}>
										{convertFloatToCurrency(data.valor)}
									</Text>
								)}
							</View>
						</View>
						<View>
							{/* <RightIcon name="right" size={15} color={iconColor} /> */}
						</View>
					</TouchableOpacity>
				</View>
			</View>
		</View>
	);
}

const converterAnoMesParaTexto = (anoMes: string): string => {
	const [ano, mes] = anoMes.split('-');
	const meses = [
		'Janeiro',
		'Fevereiro',
		'Março',
		'Abril',
		'Maio',
		'Junho',
		'Julho',
		'Agosto',
		'Setembro',
		'Outubro',
		'Novembro',
		'Dezembro',
	];

	const mesTexto = meses[parseInt(mes, 10) - 1];

	return `${mesTexto}`;
};

const FiltroExtrato = ({
	listFundosGlobal,
	loadMoreData = () => {},
	showMore,
}: any): React.JSX.Element => {
	const groupedTransactions: {
		[key: string]: {[key: string]: Transaction[]},
	} = {};

	listFundosGlobal.forEach((transaction: Transaction) => {
		const yearMonth = transaction.data.substring(0, 7);
		const day = transaction.data.substring(8, 10);

		if (!groupedTransactions[yearMonth]) {
			groupedTransactions[yearMonth] = {};
		}

		if (!groupedTransactions[yearMonth][day]) {
			groupedTransactions[yearMonth][day] = [];
		}

		groupedTransactions[yearMonth][day].push(transaction);
	});

	const groupedData = Object.keys(groupedTransactions).map(yearMonth => ({
		yearMonth,
		days: groupedTransactions[yearMonth],
	}));

	return (
		<FlatList
			data={groupedData}
			keyExtractor={item => item.yearMonth}
			renderItem={({item}) => (
				<>
					<View style={styles.cardNomeMes}>
						<Text style={styles.titleMes}>
							{converterAnoMesParaTexto(item.yearMonth)}
						</Text>
					</View>
					{Object.keys(item.days).reverse().map(day => {
						return (
							<View key={day}>
								<View style={styles.containerDia}>
									<Text style={styles.titleDia}>
										{format(
											new Date(`${item.yearMonth}-${day}`),
											"dd 'de' MMMM 'de' yyyy",
											{locale: ptBR},
										)}
									</Text>
									<View style={styles.dividerLinha}></View>
								</View>
								{item.days[day].map(transaction => (
									<ListaExtrato key={transaction.id} data={transaction} />
								))}
							</View>
						);
					})}
				</>
			)}
			onEndReached={e => {
				if (!showMore) {
					loadMoreData();
				}
			}}
			onEndReachedThreshold={0.1}
			showsVerticalScrollIndicator={true}
		/>
	);
};

export default FiltroExtrato;
