import * as React from 'react';
import {
	View,
	Text,
	ImageBackground,
	StyleSheet,
	Image,
	KeyboardAvoidingView,
	Platform,
	Dimensions,
	ScrollView,
} from 'react-native';

import LinearGradient from 'react-native-linear-gradient';
import {Button} from 'react-native-elements';
import IconFontAwesome5 from 'react-native-vector-icons/FontAwesome5';

const Atendimento: React.FC = ({navigation}: any) => {
	const goBack = () => {
		navigation.goBack();
	};

	const PrivacidadeScreeConteiner = () => {
		return (
			<LinearGradient
				colors={['rgba(45, 67, 87, 1)', 'rgba(45, 67, 87, 0.4)']}
				style={styles.linearGradient}>
				<KeyboardAvoidingView
					behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
					style={styles.PrivacidadeFormContainer}>
					<ScrollView>
						<View style={styles.row}>
							<View style={styles.container}>
								<IconFontAwesome5
									name="whatsapp"
									size={80}
									color="#fff"
									style={styles.iconePrivacy}
								/>
								<Text style={styles.sectionTitle}>WhatsApp</Text>
								<Text style={styles.textSimples}>Todos os dias 24 horas</Text>
								<Text style={styles.sectionTitle}>Atendimento anncora</Text>
								<Text style={styles.textSimples}>De segunda a domingo</Text>
								<Text style={styles.textSimples}>
									das 8h às 22h, inclusive feriados
								</Text>

								<View style={styles.linhaHorizontal} />

								<Text style={styles.textSimples}>WhastApp</Text>
								<Text style={styles.sectionTitle}>+55 (31) 9733-0000</Text>
								<View style={styles.linhaHorizontal} />

								<Text style={styles.textSimples}>SAC</Text>
								<Text style={styles.sectionTitle}>sac@anncora.com.br</Text>

								<View style={styles.buttonConteirne}>
									<Button onPress={goBack} title={'Voltar'}></Button>
								</View>
							</View>
						</View>
					</ScrollView>
				</KeyboardAvoidingView>
			</LinearGradient>
		);
	};

	return (
		<View style={styles.container}>
			<ImageBackground
				source={require('../../assets/backgrounds/predio-gradiente.png')}
				style={styles.backgroundImage}>
				<View style={styles.logoContainer}>
					<Image
						source={require('../../assets/logos/logo_branca.png')}
						style={styles.logo}
					/>
				</View>
				<PrivacidadeScreeConteiner />
			</ImageBackground>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		alignItems: 'center',
		minWidth: 400,
	},
	backgroundImage: {
		flex: 1,
		resizeMode: 'cover',
		alignItems: 'center',
		justifyContent: 'flex-end',
		width: '100%',
	},
	logoContainer: {
		position: 'absolute',
		top: 0,
	},
	logo: {
		maxWidth: Dimensions.get('window').width * 0.3,
		height: Dimensions.get('window').height * 0.24,
		resizeMode: 'contain',
	},
	PrivacidadeFormContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		borderTopLeftRadius: 30,
		borderTopRightRadius: 30,
	},
	linearGradient: {
		flex: 1,
		width: '100%',
		borderTopLeftRadius: 30,
		borderTopRightRadius: 30,
		maxHeight: Dimensions.get('window').height * 0.9,
	},
	checkboxContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10,
	},
	forgotPasswordText: {
		color: 'white',
	},
	row: {
		flexDirection: 'column',
		alignItems: 'center',
		marginBottom: 10,
	},
	title: {
		fontSize: 30,
		fontWeight: 'bold',
		marginBottom: 10,
		color: '#fff',
	},
	sectionTitle: {
		fontSize: 24,
		fontWeight: 'bold',
		color: '#fff',
	},
	textSimples: {
		fontSize: 18,
		color: '#fff',
	},
	iconePrivacy: {
		marginTop: 40,
		color: '#fff',
	},
	buttonConteirne: {
		marginTop: 30,
		width: 200,
	},
	buttonOK: {
		color: '#426385',
	},
	linhaHorizontal: {
		height: 1,
		backgroundColor: '#fff',
		alignSelf: 'stretch',
		marginBottom: 10,
		marginTop: 10,
	},
});

export default Atendimento;
