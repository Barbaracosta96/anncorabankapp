import * as React from 'react';
import {
	View,
	Text,
	ImageBackground,
	StyleSheet,
	Image,
	KeyboardAvoidingView,
	Platform,
	Dimensions,
	ScrollView,
} from 'react-native';
import IconMaterial from 'react-native-vector-icons/MaterialIcons';
import LinearGradient from 'react-native-linear-gradient';
import {Button} from 'react-native-elements';

const Privacidade: React.FC = ({navigation}: any) => {
	const goBack = () => {
		navigation.goBack();
	};

	const PrivacidadeScreeConteiner = () => {
		return (
			<LinearGradient
				colors={['rgba(45, 67, 87, 1)', 'rgba(45, 67, 87, 0.4)']}
				style={styles.linearGradient}>
				<ScrollView>
					<KeyboardAvoidingView
						behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
						style={styles.PrivacidadeFormContainer}>
						<IconMaterial
							name="privacy-tip"
							size={40}
							color="#fff"
							style={styles.iconePrivacy}
						/>
						<Text style={styles.title2}>Politica de Privacidade</Text>
						<View style={styles.row}>
							<View style={styles.container}>
								<Text style={styles.textSimples}>
									Bem-vindo(a) à Política de Privacidade do anncora bank! Esta
									política descreve como coletamos, usamos, compartilhamos e
									protegemos as informações pessoais dos usuários de nosso
									aplicativo.
								</Text>
								<Text style={styles.sectionTitle}>
									1. Informações que Coletamos
								</Text>
								<Text style={styles.textSimples}>
									Ao usar nosso aplicativo, podemos coletar as seguintes
									informações:{`\n`}- Informações de contato, como nome, e-mail,
									número de telefone, endereço; {`\n`}- Informações de login,
									como nome de usuário, senha e informações de segurança da
									conta;{`\n`}- Informações de perfil, como foto de perfil, data
									de nascimento, sexo, estado civil, nacionalidade, ocupação,
									educação e interesses;{`\n`}- Informações de pagamento, como
									número de cartão de crédito e informações de conta bancária;
									{`\n`}- Informações sobre transações, como histórico de
									compras e pagamentos;{`\n`}- Informações sobre como você
									interage com nosso aplicativo, serviço, e conteúdo, incluindo
									informações sobre seu computador ou dispositivo móvel e
									conexão com a Internet.{`\n`}
								</Text>
								<Text style={styles.sectionTitle}>2. Uso das Informações</Text>
								<Text style={styles.textSimples}>
									Usamos as informações coletadas para:{`\n`}- Fornecer, manter
									e melhorar nosso aplicativo;{`\n`}- Personalizar e melhorar
									sua experiência;{`\n`}- Oferecer suporte ao cliente;{`\n`}-
									Desenvolver novos produtos e recursos;{`\n`}- Proteger nossos
									usuários e fornecer segurança;{`\n`}- Enviar notificações de
									e-mail;{`\n`}- Enviar ofertas promocionais;{`\n`}- Enviar
									atualizações administrativas;{`\n`}- Realizar transações
									financeiras;{`\n`}- Gerenciar pagamentos;{`\n`}- Prevenir
									fraudes e atividades ilegais;{`\n`}- Cumprir obrigações
									legais.{`\n`}
								</Text>
								<Text style={styles.sectionTitle}>
									3. Compartilhamento de Informações
								</Text>
								<Text style={styles.textSimples}>
									Não compartilhamos suas informações pessoais com terceiros,
									exceto nas seguintes situações:{`\n`}- Suas informações podem
									ser compartilhadas com provedores de serviços terceirizados
									que fornecem serviços em nosso nome, incluindo processamento
									de cartão de crédito, análise de dados, pesquisa de mercado,
									atendimento ao cliente, entrega de e-mails e hospedagem de
									sites;{`\n`}- Podemos compartilhar suas informações para
									cumprir obrigações legais;{`\n`}- Podemos compartilhar suas
									informações para proteger e defender os direitos e propriedade
									da anncora bank;{`\n`}- Podemos compartilhar suas informações
									com parceiros de negócios para oferecer produtos e serviços;
									{`\n`}- Podemos compartilhar suas informações para realizar
									transferências comerciais;
									{`\n`}- Podemos compartilhar suas informações com seu
									consentimento ou conforme solicitado por você.{`\n`}
								</Text>
								<Text style={styles.sectionTitle}>
									4. Cookies e Tecnologias Semelhantes
								</Text>
								<Text style={styles.textSimples}>
									Nosso aplicativo pode usar cookies e tecnologias semelhantes
									para coletar informações sobre sua atividade e melhorar sua
									experiência.
								</Text>
								<Text style={styles.sectionTitle}>5. Segurança</Text>
								<Text style={styles.textSimples}>
									Tomamos medidas de segurança adequadas para proteger suas
									informações contra acesso não autorizado, alteração ou
									divulgação.
								</Text>
								<Text style={styles.sectionTitle}>6. Nossos Detalhes</Text>
								<Text style={styles.textSimples}>
									anncora bank ltda - CNPJ 48.570.150/0001-67{'\n'}Rua Paraíba, 550 -
									sala 900 - Belo Horizonte/MG
								</Text>

								<View style={styles.buttonOK}>
									<Button
										onPress={goBack}
										title={'Voltar'}
										style={{borderRadius: 20}}></Button>
								</View>
							</View>
						</View>
					</KeyboardAvoidingView>
				</ScrollView>
			</LinearGradient>
		);
	};

	return (
		<View style={styles.container}>
			<ImageBackground
				source={require('../../assets/backgrounds/predio-gradiente.png')}
				style={styles.backgroundImage}>
				<View style={styles.logoContainer}>
					<Image
						source={require('../../assets/logos/logo_branca.png')}
						style={styles.logo}
					/>
				</View>
				<PrivacidadeScreeConteiner />
			</ImageBackground>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	backgroundImage: {
		flex: 1,
		resizeMode: 'cover',
		alignItems: 'center',
		justifyContent: 'flex-end',
	},
	logoContainer: {
		position: 'absolute',
		top: 0,
	},
	logo: {
		maxWidth: Dimensions.get('window').width * 0.3,
		height: Dimensions.get('window').height * 0.24,
		resizeMode: 'contain',
	},
	PrivacidadeFormContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		padding: 20,
		borderTopLeftRadius: 30,
		borderTopRightRadius: 30,
	},
	linearGradient: {
		flex: 1,
		width: '100%',
		borderTopLeftRadius: 30,
		borderTopRightRadius: 30,
		maxHeight: Dimensions.get('window').height * 0.9,
	},
	checkboxContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10,
	},
	forgotPasswordText: {
		color: 'white',
	},
	row: {
		flexDirection: 'column',
		alignItems: 'center',
		marginBottom: 10,
	},
	title: {
		fontSize: 24,
		fontWeight: 'bold',
		marginBottom: 10,
		color: '#fff',
	},
	sectionTitle: {
		fontSize: 14,
		fontWeight: 'bold',
		marginTop: 10,
		color: '#fff',
	},
	textSimples: {
		color: '#fff',
		textAlign: 'justify',
	},
	title2: {
		color: 'white',
		fontSize: 20,
		marginTop: 20,
		paddingBottom: 10,
	},
	iconePrivacy: {
		marginTop: 80,
		color: '#fff',
	},
	buttonOK: {
		marginTop: 40,
		color: '#426385',
	},
});

export default Privacidade;
