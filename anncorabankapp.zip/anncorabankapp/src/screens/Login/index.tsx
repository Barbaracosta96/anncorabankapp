import * as React from 'react';
import {useState} from 'react';
import {
	View,
	Text,
	ImageBackground,
	StyleSheet,
	TouchableOpacity,
	Image,
	TextInput,
	KeyboardAvoidingView,
	Platform,
	Dimensions,
	ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import IconMaterial from 'react-native-vector-icons/MaterialIcons';
import {useDispatch} from 'react-redux';

import Loading from '../../components/Loading';
import InfoModal from '../../components/InfoModal';

import {login} from '../../api/login';

import {storeJWT as storeJWTRedux} from '../../redux/actions/authActions';
import {setUserData} from '../../redux/actions/userActions';

import {getFirstName} from '../../utils/getData';
import {isValidEmail} from '../../utils/validationMask';

const Login: React.FC = ({navigation}: any) => {
	const dispatch = useDispatch();
	const [rememberAccount, setRememberAccount] = useState(false);
	const [loading, setLoading] = useState(false);

	const [showModal, setShowModal] = useState(false);
	const [textModal, setTextModal] = useState('');

	const handleLoginError = () => {
		setTextModal('Usuário e senha inválidos');
		setShowModal(true);
	};

	const handleLogin = async (email: string, password: string) => {
		if (!email || !password) return;

		if (isValidEmail(email) === false) {
			setTextModal('E-mail inválido');
			setShowModal(true);
			return;
		}

		try {
			setLoading(true);
			const response = await login(email, password);

			if (response.status === 200) {
				const {usuario_conta} = response.data;
				const nomeUser = getFirstName(usuario_conta?.nome);

				const status = usuario_conta?.situacao?.sigla;

				if (status === 'atv') {
					const userData = {
						id: usuario_conta.id,
						name: nomeUser,
						fullName: usuario_conta.nome,
						email: usuario_conta.email,
						codinstituicao: usuario_conta.codinstituicao,
						perfilid: usuario_conta.perfil_id,
						numeroConta: usuario_conta.conta,
						tipoConta: usuario_conta.tipo_conta,
						telefone: usuario_conta.telefone,
						docCliente: usuario_conta.numero_documento,
						tipo_auth_transacao: usuario_conta.tipo_auth_transacao,
					};

					dispatch(storeJWTRedux(response.data.token));
					dispatch(setUserData(userData));
					navigation.navigate('ContainerTabs');
				} else if (status === 'pedi') {
					navigation.navigate('RegisterContainer', {
						screen: 'PreIdWall',
						params: {
							email,
							password,
						},
					});
				} else if (status === 'pac') {
					navigation.navigate('RegisterContainer', {
						screen: 'Analise',
					});
				} else {
					handleLoginError();
				}
			} else {
				handleLoginError();
			}
		} catch (error) {
			handleLoginError();
			console.log(error);
		} finally {
			setLoading(false);
		}
	};

	const LoginForm = () => {
		const [email, setEmail] = useState('');
		const [password, setPassword] = useState('');

		return (
			<LinearGradient
				colors={['rgba(45, 67, 87, 1)', 'rgba(45, 67, 87, 0.4)']}
				style={styles.linearGradient}>
				<ScrollView>
					<KeyboardAvoidingView
						behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
						style={styles.loginFormContainer}>
						<Text
							style={{
								color: 'white',
								fontSize: 20,
								marginTop: 20,
								paddingBottom: 10,
							}}>
							Informe seus dados
						</Text>
						<TextInput
							value={email}
							placeholder="Email"
							placeholderTextColor="white"
							style={styles.input}
							onChangeText={text => setEmail(text)}
						/>
						<TextInput
							value={password}
							placeholder="Senha"
							placeholderTextColor="white"
							secureTextEntry={true}
							style={styles.input}
							onChangeText={text => setPassword(text)}
						/>
						<TouchableOpacity
							style={styles.accessButton}
							onPress={() => handleLogin(email, password)}>
							<Text style={styles.accessButtonText}>ACESSAR CONTA</Text>
						</TouchableOpacity>
						<View style={styles.row}>
							<View style={styles.checkboxContainer}>
								<TouchableOpacity
									onPress={() => setRememberAccount(!rememberAccount)}
									activeOpacity={0.7}
									style={styles.checkboxContainer}>
									<IconMaterial
										name={
											rememberAccount ? 'check-box' : 'check-box-outline-blank'
										}
										size={20}
										color="white"
										style={styles.checkbox}
									/>
									<Text style={styles.forgotPasswordText}>
										Lembrar do meu e-mail
									</Text>
								</TouchableOpacity>
							</View>
							{/* <TouchableOpacity style={{marginTop: 5}}>
							<Text style={styles.forgotPasswordText}>Esqueci minha senha</Text>
						</TouchableOpacity> */}
						</View>
					</KeyboardAvoidingView>
				</ScrollView>
			</LinearGradient>
		);
	};

	return (
		<View style={styles.container}>
			<ImageBackground
				source={require('../../assets/backgrounds/predio-gradiente.png')}
				style={styles.backgroundImage}>
				<View style={styles.logoContainer}>
					<Image
						source={require('../../assets/logos/logo_branca.png')}
						style={styles.logo}
					/>
				</View>
				<LoginForm />
			</ImageBackground>
			<Loading visible={loading} />
			<InfoModal
				visible={showModal}
				text={textModal}
				onClose={() => setShowModal(false)}
			/>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		height: Dimensions.get('window').height,
	},
	backgroundImage: {
		flex: 1,
		resizeMode: 'cover',
		justifyContent: 'center',
		alignItems: 'center',
	},
	logoContainer: {
		flex: 1,
	},
	logo: {
		maxWidth: Dimensions.get('window').width * 0.7,
		height: Dimensions.get('window').width * 0.3,
		resizeMode: 'contain',
		marginTop: Dimensions.get('window').width * 0.1,
		marginBottom: Dimensions.get('window').width * 0.1,
	},
	loginFormContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		padding: 20,
		borderTopLeftRadius: 30,
		borderTopRightRadius: 30,
		width: '100%',
	},
	linearGradient: {
		flex: 1,
		width: '100%',
		borderTopLeftRadius: 30,
		borderTopRightRadius: 30,
	},
	input: {
		width: Dimensions.get('window').width * 0.7,
		height: 40,
		borderRadius: 5,
		borderWidth: 1,
		borderColor: 'white',
		backgroundColor: 'transparent',
		marginBottom: 10,
		paddingHorizontal: 10,
		color: 'white',
	},
	accessButton: {
		backgroundColor: '#426385',
		width: Dimensions.get('window').width * 0.7,
		height: 40,
		borderRadius: 5,
		justifyContent: 'center',
		alignItems: 'center',
		marginBottom: 10,
	},
	accessButtonText: {
		color: 'white',
		fontWeight: 'bold',
	},
	checkboxContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10,
	},
	checkbox: {
		marginRight: 5,
	},
	forgotPasswordText: {
		color: 'white',
	},
	row: {
		flexDirection: 'column',
		alignItems: 'center',
		marginBottom: 10,
	},
});

export default Login;
