import * as React from 'react';
import {useEffect} from 'react';
import DeviceInfo from 'react-native-device-info';

import Container from '../../layout/Container';
import TopBar from '../../layout/TopBar';

import SaldoEmConta from '../../components/SaldoEmConta';
import AcessoRapido from '../../components/AcessoRapido';
import PixArea from '../../components/PixArea';

import {registroDispositivo, gerarAutorizacao, getSecret} from '../../api/dispositivo';

const Home: React.FC = () => {
	useEffect(() => {
		const registroDispositivoApi = async () => {
			const marca = DeviceInfo.getBrand();
			const modelo = DeviceInfo.getModel();
			const uniqueId = await DeviceInfo.getUniqueId();
			const numeroSerie = await DeviceInfo.getSerialNumber();

			const response = await registroDispositivo({
				marca: marca,
				modelo: modelo,
				imei: uniqueId,
				numero_serie: numeroSerie,
			});

			const response2 = await gerarAutorizacao();

			if (response2?.data?.data?.secret) {
				const response3 =  await getSecret(response2?.data?.data?.secret, uniqueId);
				response3?.data?.token;
			}
		};

		try {
			registroDispositivoApi();
		} catch (error) {
			console.log(error);
		}
	}, []);

	return (
		<Container>
			<TopBar />
			<SaldoEmConta />
			<AcessoRapido />
			<PixArea />
		</Container>
	);
};

export default Home;
