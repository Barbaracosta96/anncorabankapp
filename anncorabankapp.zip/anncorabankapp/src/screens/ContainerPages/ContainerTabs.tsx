import * as React from 'react';
import { View, Text, BackHandler } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StyleProp, TextStyle, ViewStyle } from 'react-native';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import Home from './home';
import Cards from './cards';
import Ballance from './ballanceScreen';
import Investments from './investments';
import Benefits from './benefits';

const Tab = createBottomTabNavigator();

interface IconTabProps {
	isFocused: boolean;
	iconName: string;
	text?: string;
	color: string;
	size: number;
	containerStyle?: StyleProp<ViewStyle>;
	iconStyle?: StyleProp<ViewStyle>;
	textStyle?: StyleProp<TextStyle>;
}

const IconTab: React.FC<IconTabProps> = ({
	isFocused,
	iconName,
	text,
	color,
	size,
	containerStyle,
	iconStyle,
	textStyle,
}) => {
	if (isFocused) {
		return (
			<View
				style={[
					{
						backgroundColor: '#030c16',
						borderRadius: 10,
						width: size + 70,
						height: size + 8,
						alignItems: 'center',
						justifyContent: 'center',
						flexDirection: 'row',
					},
					containerStyle,
				]}
			>
				<MaterialCommunityIcons
					name={iconName}
					color={color}
					size={size}
					style={[{ backgroundColor: '#030c16', borderRadius: 10 }, iconStyle]}
				/>
				<Text style={[{ color: '#fff', fontSize: 9, marginLeft: 3 }, textStyle]}>
					{text}
				</Text>
			</View>
		);
	} else {
		return (
			<MaterialCommunityIcons
				name={iconName}
				color={color}
				size={size}
				style={iconStyle}
			/>
		);
	}
};

function TabBottom() {

	useFocusEffect(
		React.useCallback(() => {
			const onBackPress = () => {
				return true;
			};
			BackHandler.addEventListener('hardwareBackPress', onBackPress);
			return () =>
				BackHandler.removeEventListener('hardwareBackPress', onBackPress);
		}, [])
	);

	return (
		<Tab.Navigator
			initialRouteName="Home"
			screenOptions={{
				unmountOnBlur: true,
				tabBarActiveTintColor: '#ffffff',
				tabBarInactiveTintColor: '#9dbbd2',
				tabBarLabelStyle: { display: 'none' },
				tabBarStyle: {
					paddingHorizontal: 20,
					backgroundColor: '#1e2d3a',
				},
				tabBarShowLabel: false,
				tabBarHideOnKeyboard: true,
			}}
		>
			<Tab.Screen
				name="Home"
				component={Home}
				options={() => ({
					tabBarIcon: ({ focused, color, size }) => {
						return (
							<IconTab
								isFocused={focused}
								iconName="home"
								text="Home"
								color={color}
								size={size}
							/>
						);
					},
					header: () => {
						return null;
					},
				})}
			/>
			<Tab.Screen
				name="Cartões"
				component={Cards}
				options={{
					tabBarIcon: ({ focused, color, size }) => (
						<IconTab
							isFocused={focused}
							iconName="credit-card-outline"
							text="Cartões"
							color={color}
							size={size}
						/>
					),
					header: () => {
						return null;
					},
				}}
			/>
			<Tab.Screen
				name="Saldos"
				component={Ballance}
				options={{
					tabBarIcon: ({ focused, color, size }) => (
						<IconTab
							isFocused={focused}
							iconName="wallet-outline"
							text="Saldos"
							color={color}
							size={size}
						/>
					),
					header: () => {
						return null;
					},
				}}
			/>
			<Tab.Screen
				name="Investimentos"
				component={Investments}
				options={{
					tabBarIcon: ({ focused, color, size }) => (
						<IconTab
							isFocused={focused}
							iconName="trending-up"
							text="Investimentos"
							color={color}
							size={size}
						/>
					),
					header: () => {
						return null;
					},
				}}
			/>
			<Tab.Screen
				name="Benefícios"
				component={Benefits}
				options={{
					tabBarIcon: ({ focused, color, size }) => (
						<IconTab
							isFocused={focused}
							iconName="gift-outline"
							text="Benefícios"
							color={color}
							size={size}
						/>
					),
					header: () => {
						return null;
					},
				}}
			/>
		</Tab.Navigator>
	);
}

export default function TabsBottom() {
	return <TabBottom />;
}
