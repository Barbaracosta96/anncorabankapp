import * as React from 'react';
import {Text, View} from 'react-native';

import Container from '../../layout/Container';
import HeaderTitle from '../../components/HeaderTitle';

const Investments: React.FC = () => {
	return (
		<Container>
			<HeaderTitle title="Investimentos" />
			<View>
				<Text>Em breve!!</Text>
			</View>
		</Container>
	);
};

export default Investments;
