import * as React from 'react';
import {Text, Image} from 'react-native';

import Container from '../../layout/Container';

import HeaderTitle from '../../components/HeaderTitle';

const Cards: React.FC = () => {
	return (
		<Container>
			<HeaderTitle title="Cartões" />
			<Text
				numberOfLines={3}
				style={{
					fontSize: 16,
					color: '#fff',
					margin: 20,
					textAlign: 'justify',
				}}>
				Em um futuro próximo, você terá a oportunidade de adquirir um dos nossos
				cartões. Enquanto isso, confira uma prévia dos nossos designs!
			</Text>
			<Image
				style={{
					marginTop: 20,
				}}
				source={require('../../assets/cards/card-black.png')}
			/>
		</Container>
	);
};

export default Cards;
