import * as React from 'react';
import {useState} from 'react';
import {Text, View, StyleSheet, Dimensions} from 'react-native';

import Container from '../../layout/Container';
import HeaderTitle from '../../components/HeaderTitle';
import ButtonMenu from '../../components/botoes/ButtonMenu';
import ButtonBalance from '../../components/botoes/ButtonBalance';
import Toast from '../../components/Toast';

const flagBrazil = require('../../assets/flags/brazil.svg');
const flagEua = require('../../assets/flags/eua.svg');
const flagUe = require('../../assets/flags/ue.svg');

const Ballance: React.FC = () => {

	const [toastVisible, setToastVisible] = useState(false);
	const [toastText, setToastText] = useState('');

	const toastShow = (toastText: string) => {
		setToastText(toastText);
		setToastVisible(true);
		setTimeout(() => {
			setToastVisible(false);
		}, 4000);
	};

	const toastShowEmDesenvolvimento = () => {
		toastShow('Em breve!!');
	};

	return (
		<Container>
			<View style={styles.container}>
				<HeaderTitle title="Meus Saldos" />
				<View>
					<Text style={styles.subtitulo}>Contas</Text>
					<View style={styles.menu}>
						<ButtonBalance
							onPress={() => {}}
							text="Real"
							svgIcon={flagBrazil}
							style={{
								marginBottom: 10,
							}}
						/>
						<ButtonMenu
							onPress={() => {toastShowEmDesenvolvimento()}}
							text="Dólar"
							svgIcon={flagEua}
							style={{
								marginBottom: 10,
							}}
						/>
						<ButtonMenu
							onPress={() => {toastShowEmDesenvolvimento()}}
							svgIcon={flagUe}
							text="Euro"
						/>
					</View>
				</View>
				{toastVisible ? (
					<Toast message={toastText} duration={3000} onClose={() => {}} />
				) : null}
			</View>
		</Container>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		flexDirection: 'column',
		alignContent: 'flex-start',
		justifyContent: 'flex-start',
		width: Dimensions.get('window').width,
	},
	subtitulo: {
		fontSize: 14,
		color: '#fff',
		textAlign: 'left',
		marginLeft: 20,
	},
	menu: {
		flex: 1,
		flexDirection: 'column',
		margin: 20,
		marginTop: 10,
	},
});

export default Ballance;
