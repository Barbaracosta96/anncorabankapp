import * as React from 'react';
import {View, Text, Image, StyleSheet, Dimensions} from 'react-native';

import Container from '../../layout/Container';
import HeaderTitle from '../../components/HeaderTitle';

const Benefits: React.FC = () => {
	return (
		<Container>
			<HeaderTitle title="Benefícios" />

			<View>
				<Text style={styles.subtitulo}>Destaques</Text>
				<View style={styles.cardContainer}>
					<View style={styles.textContainer}>
						<Text style={styles.text1}>
							Convide seus amigos para o anncora bank
						</Text>
						<Text style={styles.text2}>
							Compartilhe o banco da sua vida e divida a experiência anncora com
							quem você gosta.
						</Text>
					</View>
					<Image
						source={require('../../assets/cards/card-black-1.png')}
						style={styles.image}
						resizeMode="cover"
					/>
				</View>
			</View>
		</Container>
	);
};

const styles = StyleSheet.create({
	cardContainer: {
		backgroundColor: '#1e2d3a',
		flexDirection: 'row',
		alignItems: 'center',
		borderRadius: 8,
		padding: 16,
		width: Dimensions.get('window').width * 0.9,
		height: 200,
	},
	textContainer: {
		flex: 1,
		marginRight: 16,
	},
	text1: {
		fontSize: 16,
		color: 'white',
		marginBottom: 8,
		fontWeight: 'bold',
		paddingHorizontal: 10,
	},
	text2: {
		fontSize: 16,
		marginBottom: 8,
		paddingHorizontal: 10,
	},
	image: {
		width: 100,
		height: '100%',
		borderRadius: 8,
	},
	subtitulo: {
		fontSize: 14,
		color: '#fff',
		textAlign: 'left',
		marginBottom: 8,
	},
});

export default Benefits;
