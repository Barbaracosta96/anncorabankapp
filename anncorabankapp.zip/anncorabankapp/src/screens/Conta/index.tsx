import React, {useState, useEffect} from 'react';
import {
	Text,
	View,
	StyleSheet,
	Dimensions,
	TouchableOpacity,
} from 'react-native';
import {useSelector, useDispatch} from 'react-redux';
import DeviceInfo from 'react-native-device-info';

import ButtonMenu from '../../components/botoes/ButtonMenu';
import HeaderTitle from '../../components/HeaderTitle';
import Toast from '../../components/Toast';

import {cpfMask} from '../../utils/inputMask';

import Container from '../../layout/Container';

import {reset as resetAuth} from '../../redux/actions/authActions';
import {reset as resetUser} from '../../redux/actions/userActions';
import {reset as resetSaldo} from '../../redux/actions/saldoActions';
import {reset as resetRegisterActions} from '../../redux/actions/userRegisterActions';

const Conta = ({navigation}: any) => {
	const user = useSelector((state: any) => state?.userReducer?.user);
	const dispatch = useDispatch();
	const appVersion = DeviceInfo.getVersion();

	const getInfo	= async () => {
		const marca = DeviceInfo.getBrand();
		const modelo = DeviceInfo.getModel();
		const uniqueId = await DeviceInfo.getUniqueId();
		const numeroSerie = await DeviceInfo.getSerialNumber();
		console.log('appVersion', appVersion);
		console.log('marca', marca);
		console.log('modelo', modelo);
		console.log('uniqueId', uniqueId);
		console.log('numeroSerie', numeroSerie);
	}

	getInfo();

	const [toastVisible, setToastVisible] = useState(false);
	const [toastText, setToastText] = useState('');

	const toastShow = (toastText: string) => {
		setToastText(toastText);
		setToastVisible(true);
		setTimeout(() => {
			setToastVisible(false);
		}, 4000);
	};

	const toastShowEmDesenvolvimento = () => {
		toastShow('Em breve!!');
	};

	return (
		<Container>
			<HeaderTitle title="Conta" />

			<View style={styles.container}>
				<View>
					<Text style={styles.titulo2}>Olá,</Text>
					<Text style={styles.titulo}>{user?.name ?? ''}</Text>
					<Text style={styles.subtitulo}>
						CPF: {user?.docCliente ? cpfMask(user?.docCliente) : ''}
					</Text>
				</View>
				<View style={styles.dadosBancarios}>
					<Text style={styles.banco}>Banco: anncora bank S.A.</Text>
					<Text style={styles.agencia}>Agência: 0001</Text>
					<Text style={styles.conta}>Conta: {user?.numeroConta ?? ''}</Text>
					<ButtonMenu
						onPress={() => {
							toastShowEmDesenvolvimento();
						}}
						text="anncora bank Experience"
						nameIcon="rocket-outline"
					/>
				</View>

				<View style={styles.divider} />

				<View>
					<Text style={styles.subtitulo}>Conta</Text>
					<View style={styles.menu}>
						<ButtonMenu
							onPress={() => {
								toastShowEmDesenvolvimento();
							}}
							text="Meus dados Cadastrais"
							nameIcon="person-circle-outline"
							style={{
								borderBottomLeftRadius: 0,
								borderBottomRightRadius: 0,
							}}
						/>
						<ButtonMenu
							onPress={() => {
								toastShowEmDesenvolvimento();
							}}
							text="Anncora blue"
							nameIcon="cash-outline"
							style={{
								borderRadius: 0,
							}}
						/>
						<ButtonMenu
							onPress={() => {
								toastShowEmDesenvolvimento();
							}}
							text="Convidar amigos"
							nameIcon="people-circle-outline"
							style={{
								borderTopLeftRadius: 0,
								borderTopRightRadius: 0,
							}}
						/>
					</View>
				</View>

				<View>
					<Text style={styles.subtitulo}>Documentos</Text>
					<View style={styles.menu}>
						<ButtonMenu
							onPress={() => {
								toastShowEmDesenvolvimento();
							}}
							text="Solicitar declaração de dados"
							nameIcon="reader-outline"
							style={{
								borderBottomLeftRadius: 0,
								borderBottomRightRadius: 0,
							}}
						/>
						<ButtonMenu
							onPress={() => {
								toastShowEmDesenvolvimento();
							}}
							text="Informe de rendimentos"
							nameIcon="receipt-outline"
							style={{
								borderTopLeftRadius: 0,
								borderTopRightRadius: 0,
							}}
						/>
					</View>
				</View>

				<View>
					<Text style={styles.subtitulo}>Ajuda</Text>
					<View style={styles.menu}>
						<ButtonMenu
							onPress={() => {
								toastShowEmDesenvolvimento();
							}}
							text="Chat"
							nameIcon="chatbubbles-outline"
							style={{
								borderBottomLeftRadius: 0,
								borderBottomRightRadius: 0,
							}}
						/>
						<ButtonMenu
							onPress={() => {
								navigation.navigate('LoginContainer', {
									screen: 'Atendimento',
								});
							}}
							text="Canais de atendimento"
							nameIcon="call-outline"
							style={{
								borderTopLeftRadius: 0,
								borderTopRightRadius: 0,
							}}
						/>
					</View>
				</View>

				<View style={styles.sair}>
					<TouchableOpacity
						onPress={() => {
							dispatch(resetAuth());
							dispatch(resetUser());
							dispatch(resetSaldo());
							dispatch(resetRegisterActions());
							navigation.navigate('PaginaInicial');
						}}>
						<Text style={styles.sairText}>Sair da conta</Text>
					</TouchableOpacity>
					<Text>Versão: v{appVersion}</Text>
				</View>

				{toastVisible ? (
					<Toast message={toastText} duration={3000} onClose={() => {}} />
				) : null}
			</View>
		</Container>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		flexDirection: 'column',
		alignContent: 'flex-start',
		justifyContent: 'flex-start',
		width: Dimensions.get('window').width,
	},
	logo: {
		width: 100,
		height: 100,
		alignSelf: 'center',
	},
	titulo: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#fff',
		textAlign: 'left',
		marginLeft: 20,
	},
	titulo2: {
		fontSize: 14,
		fontWeight: 'bold',
		color: '#fff',
		textAlign: 'left',
		marginLeft: 20,
	},
	subtitulo: {
		fontSize: 14,
		color: '#fff',
		textAlign: 'left',
		marginLeft: 20,
	},
	sairText: {
		fontSize: 18,
		fontWeight: 'bold',
		color: '#fff',
		textAlign: 'left',
	},
	dadosBancarios: {
		margin: 20,
	},
	sair: {
		margin: 20,
		flexDirection: 'column',
		alignItems: 'center',
	},
	banco: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#fff',
	},
	agencia: {
		fontSize: 16,
		color: '#fff',
	},
	conta: {
		fontSize: 16,
		color: '#fff',
		marginBottom: 20,
	},
	menu: {
		flex: 1,
		flexDirection: 'column',
		margin: 20,
		marginTop: 10,
	},
	divider: {
		borderBottomColor: '#0b1620',
		borderBottomWidth: 2,
		marginTop: 10,
		marginBottom: 20,
		width: Dimensions.get('window').width,
	},
});

export default Conta;
