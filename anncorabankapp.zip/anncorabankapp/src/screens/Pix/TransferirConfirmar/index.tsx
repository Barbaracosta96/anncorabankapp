import * as React from 'react';
import {useState} from 'react';
import {
	View,
	Text,
	TextInput,
	StyleSheet,
	ScrollView,
	Alert,
} from 'react-native';
import DeviceInfo from 'react-native-device-info';

import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';
import {CommonActions} from '@react-navigation/native';

import {useSelector} from 'react-redux';

import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';

import {telefoneMask, cpfMask, cnpjMask} from '../../../utils/inputMask';

import {convertFloatToCurrency} from '../../../utils/moneyMask';

import {pixCachOut} from '../../../api/pix';
import Loading from '../../../components/Loading';

import {gerarAutorizacao, getSecret} from '../../../api/dispositivo';

const TransferirConfirmar = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const route: any = useRoute();
	const user = useSelector((state: any) => state?.userReducer?.user);

	const [value] = useState<number>(route?.params?.value ?? 0);
	const [key] = useState<string>(route?.params?.key ?? '');
	const [keyValue] = useState<string>(route?.params?.keyValue ?? '');
	const [data] = useState<any>(route?.params?.data ?? {});
	const [cpf] = useState<string>(
		route?.params?.data?.owner?.documentNumber
			? cpfMask(route?.params?.data?.owner?.documentNumber)
			: '',
	);

	const [loading, setLoading] = useState<boolean>(false);
	const [message, setMessage] = useState<string>('');

	const B = (props: any) => (
		<Text style={{fontWeight: 'bold', color: 'white'}}>{props.children}</Text>
	);

	function obscureString(inputString: string) {
		if (inputString.length < 5) {
			return;
		}
		const firstThree = '*'.repeat(3);
		const lastTwo = '*'.repeat(2);
		const middle = inputString.substring(3, inputString.length - 2);

		return firstThree + middle + lastTwo;
	}

	const convertAccountType = (accountType: string) => {
		switch (accountType) {
			case 'CACC':
				return 'Conta Corrente';
			case 'TRAN':
				return 'Conta de Pagamentos';
			case 'SLRY':
				return 'Conta Salário';
			case 'SVGS':
				return 'Conta Poupança';
			default:
				return accountType;
		}
	};

	const enviaPixApi = async () => {
		setLoading(true);
		const uniqueId = await DeviceInfo.getUniqueId();
		const responseAutorizacao = await gerarAutorizacao();
		let token;
		if (responseAutorizacao?.data?.data?.secret) {
			const responseToken = await getSecret(
				responseAutorizacao?.data?.data?.secret,
				uniqueId,
			);
			if (responseToken?.data?.token) {
				token = responseToken.data.token;
			}
		}

		if (token) {
			const dadosEnviaPix = {
				valor: String(value),
				endToEndId: data.endtoEndId,
				tipo_iniciacao_pagamento: 'DICT',
				conta_debito: {
					conta: user.numeroConta,
				},
				conta_credito: {
					banco: data.account.participant,
					chave: data.key,
					conta: data.account.account,
					agencia: data.account.branch,
					cpf_cnpj: data.owner.documentNumber,
					nome: data.owner.name,
				},
				mensagem_envio: message ?? '',
				dispositivo: {
					conta: user.numeroConta,
					totp_code: token,
				},
			};

			const response = await pixCachOut(dadosEnviaPix);
			if (response.status === 200 || response.status === 201) {
				const id = response?.data?.data?.body?.id ?? '';
				navigation.dispatch(
					CommonActions.reset({
						index: 1,
						routes: [
							{name: 'ContainerTabs'},
							{
								name: 'Comprovante',
								params: {
									value: value,
									key: key,
									keyValue: keyValue,
									data: data,
									id: id,
								},
							},
						],
					}),
				);
			} else {
				Alert.alert('Erro', 'Não foi possível realizar a transferência.');
			}
		} else {
			Alert.alert('Erro', 'Não foi possível realizar a transferência.');
		}
		setLoading(false);
	};

	return (
		<ScrollView contentContainerStyle={{flexGrow: 1}}>
			<View style={styles.container}>
				<HeaderTitle title="Transferindo" showSeparator={true} />
				<Text style={styles.modalTitle}>
					Você vai transferir <B>{convertFloatToCurrency(value)}</B> para {'\n'}
					<B>{data?.owner?.name.toUpperCase() ?? ''}</B>
				</Text>
				<TextInput
					style={styles.input}
					value={message}
					onChangeText={text => setMessage(text)}
					placeholder="Mensagem (opcional)"
					maxLength={140}
				/>

				<View style={styles.container2}>
					<View style={styles.row}>
						<Text style={styles.label}>Nome:</Text>
						<Text style={styles.value}>
							{data?.owner?.name.toUpperCase() ?? ''}
						</Text>
					</View>
					<View style={styles.row}>
						<Text style={styles.label}>CPF:</Text>
						<Text style={styles.value}>{obscureString(cpf) ?? ''}</Text>
					</View>
					<View style={styles.row}>
						<Text style={styles.label}>Instituição:</Text>
						<Text style={styles.value}>{data?.account?.participant ?? ''}</Text>
					</View>
					<View style={styles.row}>
						<Text style={styles.label}>Agência:</Text>
						<Text style={styles.value}>{data?.account?.branch ?? ''}</Text>
					</View>
					<View style={styles.row}>
						<Text style={styles.label}>
							{convertAccountType(data?.account?.accountType)}:
						</Text>
						<Text style={styles.value}>{data?.account?.account ?? ''}</Text>
					</View>
				</View>

				<View style={{flex: 1}} />

				<ButtonDefault
					onPress={enviaPixApi}
					title="Finalizar"
					iconName="checkmark-done"
					iconSize={25}
					iconColor="white"
					buttonStyle={styles.addButton}
					textStyle={styles.addButtonText}
				/>

				<Loading visible={loading} />
			</View>
		</ScrollView>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
		backgroundColor: '#151c27',
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 16,
		marginBottom: 16,
		borderRadius: 8,
		color: 'white',
		fontSize: 16,
	},
	noKeysText: {
		fontSize: 16,
		fontStyle: 'italic',
		color: 'white',
	},
	modalTitle: {
		fontSize: 20,
		color: 'white',
	},
	modalTitle2: {
		fontSize: 16,
		fontWeight: 'bold',
		marginBottom: 8,
		color: 'white',
	},
	addButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#273d4c',
		borderRadius: 8,
		padding: 12,
		marginBottom: 16,
	},
	addButtonText: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 16,
	},
	container2: {
		padding: 0,
	},
	row: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10,
	},
	label: {
		marginRight: 5,
		fontWeight: 'bold',
		color: 'white',
	},
	value: {
		fontWeight: 'normal',
	},
});

export default TransferirConfirmar;
