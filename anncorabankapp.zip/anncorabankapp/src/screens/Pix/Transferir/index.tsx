import * as React from 'react';
import {useEffect, useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';

import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

import {TextInputMask} from 'react-native-masked-text';

import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';
import Loading from '../../../components/Loading';

import {getSaldo} from '../../../api/carteira';
import {
	convertFloatToCurrency,
	convertCurrencyToFloat,
} from '../../../utils/moneyMask';

const Transferir = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const [saldo, setSaldo] = useState<string>('-');
	const [value, setValue] = useState<number>(0);
	const [loading, setLoading] = useState<boolean>(false);
	const [error, setError] = useState('');

	const showErrorLabel = (text: string) => {
		setError(text);
		setTimeout(() => {
			setError('');
		}, 3000);
	};

	useEffect(() => {
		const getSaldoApi = async () => {
			setLoading(true);
			const response = await getSaldo();
			if (response?.data?.data?.total) {
				setSaldo(convertFloatToCurrency(response?.data?.data?.total));
			}
			setLoading(false);
		};
		try {
			getSaldoApi();
		} catch (error) {
			console.log(error);
		}
	}, []);

	return (
		<ScrollView contentContainerStyle={{flexGrow: 1}}>
			<View style={styles.container}>
				<HeaderTitle title="Transferir" showSeparator={true} />
				<Text style={styles.modalTitle}>Qual é o valor?</Text>
				<Text style={styles.modalTitle2}>
					Saldo disponível em conta: {saldo ?? '-'}
				</Text>
				<TextInputMask
					style={styles.input}
					type="money"
					options={{
						precision: 2,
						separator: ',',
						delimiter: '.',
						unit: 'R$',
						suffixUnit: '',
					}}
					value={convertFloatToCurrency(value)}
					onChangeText={text => {
						setValue(convertCurrencyToFloat(text));
					}}
				/>
				<Text style={{color: '#ec407a', textAlign: 'center'}}>{error}</Text>

				<View style={{flex: 1}} />

				<ButtonDefault
					onPress={() => {
						if (value <= 0) {
							showErrorLabel('Valor inválido');
							return;
						}
						if (value > convertCurrencyToFloat(saldo)) {
							showErrorLabel('Saldo insuficiente');
							return;
						}
						navigation.navigate('TransferirDestino', {value});
					}}
					title="Avançar"
					iconName="chevron-forward-circle-outline"
					iconSize={25}
					iconColor="white"
					buttonStyle={styles.addButton}
					textStyle={styles.addButtonText}
				/>

				<Loading visible={loading} />
			</View>
		</ScrollView>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
		backgroundColor: '#151c27',
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 16,
		marginBottom: 16,
		borderRadius: 8,
		color: 'white',
		fontSize: 25,
	},
	modalTitle: {
		fontSize: 20,
		fontWeight: 'bold',
		color: 'white',
	},
	modalTitle2: {
		fontSize: 16,
		marginBottom: 8,
		color: 'white',
	},
	addButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#273d4c',
		borderRadius: 8,
		padding: 12,
		marginBottom: 16,
	},
	addButtonText: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 16,
	},
});

export default Transferir;
