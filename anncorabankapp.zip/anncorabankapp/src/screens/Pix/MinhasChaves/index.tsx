import * as React from 'react';
import {useEffect, useState} from 'react';
import {
	View,
	Text,
	FlatList,
	TouchableOpacity,
	TextInput,
	StyleSheet,
} from 'react-native';
import Clipboard from '@react-native-clipboard/clipboard';
import Icon from 'react-native-vector-icons/FontAwesome';
import {useSelector} from 'react-redux';
// @ts-ignore
import RadioButtons from 'react-native-radio-buttons';

import HeaderTitle from '../../../components/HeaderTitle';
import ModalDefault from '../../../components/ModalDefault';
import ModalConfirmation from '../../../components/ModalConfirmation';
import ButtonDefault from '../../../components/ButtonDefault';
import Loading from '../../../components/Loading';
import Toast from '../../../components/Toast';

import {telefoneMask, cpfMask} from '../../../utils/inputMask';
import {isValidEmail, isValidPhone} from '../../../utils/validationMask';

import {
	getListaChavesPix,
	removerChavePix,
	cadastrarChavePix,
	enviaCodigoConfirmacao,
	validarCodigoConfirmacao,
} from '../../../api/pix';

import {KeyType} from '../../../interfaces/pix';

const MinhasChaves = () => {
	const user = useSelector((state: any) => state?.userReducer?.user);

	const [keys, setKeys] = useState<any>([]);

	const [modalVisible, setModalVisible] = useState(false);

	const [selectedKey, setSelectedKey] = useState('CPF');
	const [inputValue, setInputValue] = useState(user?.docCliente);
	const [maskedValue, setMaskedValue] = useState(cpfMask(user?.docCliente));

	const [deleteModalVisible, setDeleteModalVisible] = useState(false);
	const [keyToDelete, setKeyToDelete] = useState('');

	const [loading, setLoading] = useState<boolean>(true);

	const [toastVisible, setToastVisible] = useState(false);
	const [toastText, setToastText] = useState('');

	const [modalConfirmationCode, setModalConfirmationCode] = useState(false);
	const [confirmationCode, setConfirmationCode] = useState('');

	const [error, setError] = useState('');
	const [error2, setError2] = useState('');

	const toastShow = (toastText: string) => {
		setToastText(toastText);
		setToastVisible(true);
		setTimeout(() => {
			setToastVisible(false);
		}, 4000);
	};

	const showErrorLabel = (text: string) => {
		setError(text);
		setTimeout(() => {
			setError('');
		}, 3000);
	};

	const showErrorLabel2 = (text: string) => {
		setError2(text);
		setTimeout(() => {
			setError2('');
		}, 3000);
	};

	useEffect(() => {
		const fetchData = async () => {
			setLoading(true);
			try {
				const response = await getListaChavesPix();
				if (response?.data?.data?.body?.listKeys) {
					const sortedKeys = response.data.data.body.listKeys.sort(
						(a: any, b: any) => {
							return a.keyType.localeCompare(b.keyType);
						},
					);
					setKeys(sortedKeys || []);
				}
			} catch (error) {
				console.log(error);
			}
			setLoading(false);
		};

		fetchData();
	}, []);

	useEffect(() => {
		if (selectedKey === 'CPF') {
			setInputValue(user?.docCliente);
			setMaskedValue(cpfMask(user?.docCliente));
		} else {
			setMaskedValue('');
		}
	}, [selectedKey]);

	const keyTypes = ['CPF', 'EMAIL', 'TELEFONE', 'EVP'];

	const keyIcons = (nameIcon: string) => {
		switch (nameIcon) {
			case 'CPF':
				return 'id-card-o';
			case 'EMAIL':
				return 'envelope-o';
			case 'TELEFONE':
				return 'phone';
			case 'EVP':
				return 'random';
			default:
				return 'id-card-o';
		}
	};

	const closeModal = () => {
		setModalVisible(false);
		setSelectedKey('CPF');
		setInputValue('');
		setMaskedValue('');
	};

	const closeDeleteModal = () => {
		setDeleteModalVisible(false);
		setKeyToDelete('');
	};

	const deleteKey = (key: string) => {
		setDeleteModalVisible(true);
		setKeyToDelete(key);
	};

	const confirmDeleteKey = async () => {
		setDeleteModalVisible(false);
		try {
			setLoading(true);
			const result = await removerChavePix(keyToDelete);
			if (result.status === 200) {
				toastShow('✅🗑️ Chave excluída com sucesso!');
				const newKeys = keys.filter((item: any) => item.key !== keyToDelete);
				setKeys(newKeys);
			} else {
				toastShow('❌ Erro ao excluir chave.');
				if (result?.data?.data?.error?.message) {
					toastShow(result?.data?.data?.error?.message);
				}
			}
		} catch (error) {
			console.log(error);
		}
		setKeyToDelete('');
		setLoading(false);
	};

	const addKey = async () => {
		if (!selectedKey || (inputValue === '' && selectedKey !== 'EVP')) {
			return;
		}

		closeModal();

		let keyType: KeyType;
		switch (selectedKey) {
			case 'CPF':
				keyType = 'cpf';
				break;
			case 'EMAIL':
				keyType = 'email';
				break;
			case 'TELEFONE':
				keyType = 'telefone';
				break;
			default:
				keyType = 'aleatoria';
				break;
		}

		if (keyType === 'cpf') {
			const cpf = inputValue.replace(/[^0-9]/g, '');
			const cpfExists = keys.find((item: any) => item.key === cpf);
			if (cpfExists) {
				toastShow('❌ CPF já cadastrado.');
				return;
			}
		}

		try {
			setLoading(true);
			const response = await cadastrarChavePix(keyType, inputValue);

			if (response.status < 200 || response.status > 299) {
				if (response?.data?.data?.error?.message) {
					toastShow(response?.data?.data?.error?.message);
				}
			} else {
				toastShow('✅ Chave adicionada com sucesso!');
				const newKey = response?.data?.data?.body?.key;
				if (newKey) {
					const newKeyObject = {keyType: selectedKey, key: newKey};
					const updatedKeys = [...keys, newKeyObject];
					const sortedKeys = updatedKeys
						.slice()
						.sort((a, b) => a.keyType.localeCompare(b.keyType));
					setKeys(sortedKeys);
				}
			}
		} catch (error) {
			console.error(error);
		} finally {
			setLoading(false);
		}
	};

	const convertKey = (keyType: string, key: string) => {
		if (keyType === 'CPF') {
			return cpfMask(key);
		} else if (keyType === 'TELEFONE') {
			return telefoneMask(key);
		} else {
			return key;
		}
	};

	const convertKeyType = (keyType: string) => {
		switch (keyType) {
			case 'CPF':
				return 'CPF';
			case 'EMAIL':
				return 'E-mail';
			case 'TELEFONE':
				return 'Telefone';
			case 'EVP':
				return 'Chave aleatória';
			default:
				return keyType;
		}
	};

	const renderItem = ({item}: any) => (
		<TouchableOpacity
			onPress={() => {
				Clipboard.setString(convertKey(item.keyType, item.key));
				toastShow('🔑 Chave copiada ' + convertKey(item.keyType, item.key));
			}}>
			<View style={styles.card}>
				<TouchableOpacity
					onPress={() => deleteKey(item.key)}
					style={styles.deleteIcon}>
					<Icon name="trash" size={20} color="#ec407a" />
				</TouchableOpacity>
				<View style={styles.cardIconContainer}>
					<Icon
						name={keyIcons(item.keyType)}
						size={24}
						color="black"
						style={styles.cardIcon}
					/>
				</View>
				<View style={styles.cardTextContainer}>
					<Text style={styles.cardKeyType}>{convertKeyType(item.keyType)}</Text>
					<Text style={styles.cardText}>
						{convertKey(item.keyType, item.key)}
					</Text>
				</View>
				<TouchableOpacity
					onPress={() => {
						Clipboard.setString(convertKey(item.keyType, item.key));
						toastShow('🔑 Chave copiada ' + convertKey(item.keyType, item.key));
					}}
					style={styles.copyIcon}>
					<Icon name="copy" size={20} color="#82c4ff" />
				</TouchableOpacity>
			</View>
		</TouchableOpacity>
	);

	return (
		<View style={styles.container}>
			<HeaderTitle title="Minhas Chaves PIX" showSeparator={true} />

			{keys.length === 0 && !loading ? (
				<Text style={styles.noKeysText}>
					Você não tem nenhuma chave cadastrada
				</Text>
			) : (
				<FlatList
					data={keys}
					keyExtractor={item => item.key}
					renderItem={renderItem}
				/>
			)}

			{toastVisible ? (
				<Toast message={toastText} duration={3000} onClose={() => {}} />
			) : null}

			<Loading visible={loading} />

			<ButtonDefault
				onPress={() => {
					setSelectedKey('CPF');
					setInputValue(user?.docCliente);
					setMaskedValue(cpfMask(user?.docCliente));
					setConfirmationCode('');
					setModalConfirmationCode(false);
					setModalVisible(true);
				}}
				title="Adicionar Chave"
				iconName="add-circle-outline"
				iconSize={25}
				iconColor="white"
				buttonStyle={styles.addButton}
				textStyle={styles.addButtonText}
			/>

			<ModalDefault isVisible={modalVisible} setIsVisible={setModalVisible}>
				<Text style={styles.modalTitle}>SELECIONE:</Text>
				<RadioButtons
					options={keyTypes}
					onSelection={(selectedOption: React.SetStateAction<string>) =>
						setSelectedKey(selectedOption)
					}
					selectedOption={selectedKey}
					renderOption={(
						option: any,
						selected: boolean,
						onSelect: () => void,
						index: number,
					) => (
						<TouchableOpacity
							onPress={onSelect}
							key={index}
							style={styles.radioButton}>
							<View
								style={[
									styles.radioButtonCircle,
									{borderColor: selected ? '#75b7e4' : 'gray'},
								]}>
								{selected && <View style={styles.radioButtonSelectedCircle} />}
							</View>
							<Text
								style={
									selected
										? styles.selectedRadioButtonText
										: styles.radioButtonText
								}>
								{convertKeyType(option)}
							</Text>
						</TouchableOpacity>
					)}
				/>
				{selectedKey && (
					<View>
						{selectedKey === 'EVP' ? null : (
							<TextInput
								value={maskedValue}
								editable={selectedKey === 'CPF' ? false : true}
								onChangeText={text => {
									setInputValue(text);
									if (selectedKey === 'CPF') {
										setMaskedValue(cpfMask(user?.docCliente));
									} else if (selectedKey === 'TELEFONE') {
										setMaskedValue(telefoneMask(text));
									} else {
										setMaskedValue(text);
									}
								}}
								keyboardType={
									selectedKey === 'CPF' || selectedKey == 'TELEFONE'
										? 'numeric'
										: 'default'
								}
								placeholder={
									selectedKey === 'CPF'
										? '000.000.000-00'
										: selectedKey === 'TELEFONE'
										? '(00) 00000-0000'
										: selectedKey === 'EMAIL'
										? 'seuemail@provedor.com'
										: ''
								}
								placeholderTextColor="gray"
								style={styles.input}
							/>
						)}
						<Text style={{color: '#ec407a', textAlign: 'center'}}>{error}</Text>
						<ButtonDefault
							onPress={() => {
								if (selectedKey === 'TELEFONE' || selectedKey === 'EMAIL') {
									if (selectedKey === 'TELEFONE') {
										if (!isValidPhone(maskedValue)) {
											showErrorLabel('Telefone inválido');
											return;
										}
										enviaCodigoConfirmacao('sms', maskedValue);
									} else {
										if (!isValidEmail(maskedValue)) {
											showErrorLabel('E-mail inválido');
											return;
										}
										enviaCodigoConfirmacao('email', maskedValue);
									}
									setModalVisible(false);
									setModalConfirmationCode(true);
								} else {
									addKey();
								}
							}}
							title={
								selectedKey === 'TELEFONE' || selectedKey === 'EMAIL'
									? 'Avançar'
									: 'Adicionar'
							}
							iconName={
								selectedKey === 'TELEFONE' || selectedKey === 'EMAIL'
									? 'arrow-forward-outline'
									: 'archive-outline'
							}
							iconSize={20}
							iconColor="white"
							buttonStyle={styles.saveButton}
						/>
					</View>
				)}
			</ModalDefault>

			<ModalDefault
				isVisible={modalConfirmationCode}
				setIsVisible={setModalConfirmationCode}>
				<Text style={styles.modalTitle}>Digite o código de confirmação:</Text>
				<Text style={styles.noKeysText}>
					Enviado para: {convertKey(selectedKey, inputValue)}
				</Text>
				<TextInput
					style={styles.input}
					value={confirmationCode}
					keyboardType="numeric"
					onChangeText={text => {
						const newText = text.replace(/[^0-9]/g, '');
						setConfirmationCode(newText);
					}}
					maxLength={6}
				/>
				<Text style={{color: '#ec407a', textAlign: 'center'}}>{error2}</Text>
				<ButtonDefault
					onPress={async () => {
						let keyType: | 'sms' | 'email';
						if(selectedKey === 'TELEFONE') {
							keyType = 'sms';
						} else {
							keyType = 'email';
						}
						setLoading(true);
						const result = await validarCodigoConfirmacao(keyType, inputValue, confirmationCode);
						setLoading(false);
						if(result.status === 422) {
							showErrorLabel2('Código inválido');
							return;
						}
						setModalConfirmationCode(false);
						setError('');
						setError2('');
						if(result.status === 200) {
							addKey();
						} else {
							toastShow('❌ Erro ao adicionar chave.');
						}
					}}
					title="Confirmar"
					iconName="checkmark"
					iconSize={20}
					iconColor="white"
					buttonStyle={styles.saveButton}
				/>
			</ModalDefault>

			<ModalConfirmation
				isVisible={deleteModalVisible}
				setIsVisible={setDeleteModalVisible}
				onPressYes={confirmDeleteKey}
				onPressNot={closeDeleteModal}
				title="Deseja realmente excluir esta chave PIX?"
			/>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
		backgroundColor: '#151c27',
	},
	card: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: '#273d4c',
		padding: 16,
		marginBottom: 8,
		borderRadius: 8,
		elevation: 3,
	},
	cardIconContainer: {
		marginRight: 16,
	},
	cardTextContainer: {
		flex: 1,
	},
	cardIcon: {
		color: '#75b7e4',
	},
	cardKeyType: {
		color: 'white',
		fontSize: 16,
		fontWeight: 'bold',
	},
	cardText: {
		color: 'white',
		fontSize: 12,
	},
	deleteIcon: {
		marginRight: 12,
	},
	copyIcon: {
		marginRight: 12,
	},
	addButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#273d4c',
		borderRadius: 8,
		padding: 12,
		marginBottom: 16,
	},
	addButtonText: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 16,
	},
	noKeysText: {
		fontSize: 16,
		fontStyle: 'italic',
		color: 'white',
	},
	modalTitle: {
		fontSize: 16,
		fontWeight: 'bold',
		marginBottom: 8,
		color: 'white',
	},
	radioButton: {
		flexDirection: 'row',
		alignItems: 'center',
		marginVertical: 8,
	},
	radioButtonCircle: {
		borderWidth: 2,
		borderRadius: 12,
		width: 24,
		height: 24,
		marginRight: 8,
		alignItems: 'center',
		justifyContent: 'center',
	},
	radioButtonSelectedCircle: {
		width: 12,
		height: 12,
		borderRadius: 6,
		backgroundColor: '#75b7e4',
	},
	radioButtonText: {
		fontSize: 16,
		color: 'white',
	},
	selectedRadioButtonText: {
		fontSize: 16,
		color: '#75b7e4',
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 16,
		marginBottom: 16,
		borderRadius: 8,
		color: 'white',
	},
	saveButton: {
		backgroundColor: '#151c27',
	},
});

export default MinhasChaves;
