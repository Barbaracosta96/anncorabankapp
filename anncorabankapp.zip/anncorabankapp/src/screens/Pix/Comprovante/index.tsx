import * as React from 'react';
import {useState, useRef} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import Share from 'react-native-share';
import ViewShot from 'react-native-view-shot';

import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

import {useSelector} from 'react-redux';
import moment from 'moment';

import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';

import {telefoneMask, cpfMask, cnpjMask} from '../../../utils/inputMask';

import {convertFloatToCurrency} from '../../../utils/moneyMask';

import Loading from '../../../components/Loading';
import { set } from 'date-fns';

const Comprovante = () => {
	const viewShotRef = useRef();
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const route: any = useRoute();
	const user = useSelector((state: any) => state?.userReducer?.user);

	const [value] = useState<number>(route?.params?.value ?? 0);
	const [key] = useState<string>(route?.params?.key ?? '');
	const [keyValue] = useState<string>(route?.params?.keyValue ?? '');
	const [data] = useState<any>(route?.params?.data ?? {});
	const [id] = useState<string>(route?.params?.id ?? '');
	const [cpf] = useState<string>(
		route?.params?.data?.owner?.documentNumber
			? cpfMask(route?.params?.data?.owner?.documentNumber)
			: '',
	);

	const [loading, setLoading] = useState<boolean>(false);

	const B = (props: any) => (
		<Text style={{fontWeight: 'bold', color: 'white'}}>{props.children}</Text>
	);

	function obscureString(inputString: string) {
		if (!inputString) {
			return;
		}
		if (typeof inputString !== 'string') {
			// @ts-ignore
			inputString = inputString?.toString();
		}
		if (inputString.length < 5) {
			return;
		}
		const firstThree = '*'.repeat(3);
		const lastTwo = '*'.repeat(2);
		const middle = inputString.substring(3, inputString.length - 2);

		return firstThree + middle + lastTwo;
	}

	const convertAccountType = (accountType: string) => {
		switch (accountType) {
			case 'CACC':
				return 'Conta Corrente';
			case 'TRAN':
				return 'Conta de Pagamentos';
			case 'SLRY':
				return 'Conta Salário';
			case 'SVGS':
				return 'Conta Poupança';
			default:
				return accountType;
		}
	};

	const shareScreenshot = async () => {
		try {
			setLoading(true);
			// @ts-ignore
			const imageURI = await viewShotRef.current.capture();

			const shareOptions = {
				message: 'Comprovante de transferência',
				url: `data:image/png;base64,${imageURI}`,
			};

			await Share.open(shareOptions);
			setLoading(false);
		} catch (error) {
			setLoading(false);
			console.error('Error sharing:', error);
		} finally {
			setLoading(false);
		}
	};

	return (
		<>
			<ScrollView contentContainerStyle={{flexGrow: 1}}>
				<View style={styles.container}>
					<View style={{flex: 1}}>
						<HeaderTitle title="Transferência" showSeparator={true} />
						<Text style={styles.modalTitle}>Comprovante de transferência</Text>
						<Text style={styles.modalTitle2}>
							{moment().format('DD/MM/YYYY')} - {moment().format('HH:mm:ss')}
						</Text>
						<ViewShot
							ref={viewShotRef as any}
							options={{format: 'png', quality: 0.9}}
							style={{flex: 1}}>

							<View style={styles.container2}>
								<View style={{...styles.row, marginTop: 20}}>
									<Text style={styles.label}>Valor:</Text>
									<Text style={styles.value2}>
										<B>{convertFloatToCurrency(value)}</B>
									</Text>
								</View>

								<View style={styles.row}>
									<Text style={styles.label}>Tipo:</Text>
									<Text style={styles.value}>PIX</Text>
								</View>

								<View style={styles.separator} />
								<Text style={styles.modalTitle2}>ORIGEM</Text>
								<View style={styles.separator} />

								<View style={styles.row}>
									<Text style={styles.label}>Nome:</Text>
									<Text style={styles.value}>
										{data?.owner?.name.toUpperCase() ?? ''}
									</Text>
								</View>
								<View style={styles.row}>
									<Text style={styles.label}>CPF:</Text>
									<Text style={styles.value}>{obscureString(cpf) ?? ''}</Text>
								</View>
								<View style={styles.row}>
									<Text style={styles.label}>Instituição:</Text>
									<Text style={styles.value}>
										{data?.account?.participant ?? ''}
									</Text>
								</View>
								<View style={styles.row}>
									<Text style={styles.label}>Agência:</Text>
									<Text style={styles.value}>{data?.account?.branch ?? ''}</Text>
								</View>
								<View style={styles.row}>
									<Text style={styles.label}>
										{convertAccountType(data?.account?.accountType)}:
									</Text>
									<Text style={styles.value}>{data?.account?.account ?? ''}</Text>
								</View>

								<View style={styles.separator} />
								<Text style={styles.modalTitle2}>DESTINO</Text>
								<View style={styles.separator} />

								<View style={styles.row}>
									<Text style={styles.label}>Nome:</Text>
									<Text style={styles.value}>
										{user?.name.toUpperCase() ?? ''}
									</Text>
								</View>

								<View style={styles.row}>
									<Text style={styles.label}>CPF:</Text>
									<Text style={styles.value}>
										{obscureString(cpfMask(user?.docCliente)) ?? ''}
									</Text>
								</View>

								<View style={styles.row}>
									<Text style={styles.label}>Instituição:</Text>
									<Text style={styles.value}>Anncora Bank</Text>
								</View>

								<View style={styles.row}>
									<Text style={styles.label}>Agência:</Text>
									<Text style={styles.value}>{'0001'}</Text>
								</View>

								<View style={styles.row}>
									<Text style={styles.label}>Conta:</Text>
									<Text style={styles.value}>{user?.numeroConta ?? ''}</Text>
								</View>
							</View>

							<View style={styles.separator} />

							<View style={styles.row}>
								<Text style={styles.label}>ID:</Text>
								<Text style={styles.value}>{id ?? ''}</Text>
							</View>
						</ViewShot>

						<View style={{flex: 1}} />

						<ButtonDefault
							onPress={() => shareScreenshot()}
							title="Compartilhar"
							iconName="share-social-outline"
							iconSize={25}
							iconColor="white"
							buttonStyle={styles.addButton}
							textStyle={styles.addButtonText}
						/>

					</View>
				</View>
			</ScrollView>
			<Loading visible={loading} />
		</>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
		backgroundColor: '#151c27',
	},
	separator: {
		borderBottomColor: 'gray',
		borderBottomWidth: 1,
		marginVertical: 8,
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 16,
		marginBottom: 16,
		borderRadius: 8,
		color: 'white',
		fontSize: 16,
	},
	noKeysText: {
		fontSize: 16,
		fontStyle: 'italic',
		color: 'white',
	},
	modalTitle: {
		fontSize: 20,
		color: 'white',
	},
	modalTitle2: {
		fontSize: 12,
		marginHorizontal: 4,
		color: 'white',
	},
	addButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#273d4c',
		borderRadius: 8,
		padding: 12,
		marginBottom: 16,
	},
	addButtonText: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 16,
	},
	container2: {
		padding: 0,
	},
	row: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10,
	},
	label: {
		marginRight: 5,
		fontWeight: 'bold',
		color: 'white',
	},
	value: {
		fontWeight: 'normal',
	},
	value2: {
		fontSize: 18,
		fontWeight: 'normal',
	},
});

export default Comprovante;
