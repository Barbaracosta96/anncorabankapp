import * as React from 'react';
import {useState} from 'react';
import {View, Text, TextInput, StyleSheet, ScrollView} from 'react-native';

import {useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

import HeaderTitle from '../../../components/HeaderTitle';
import ButtonDefault from '../../../components/ButtonDefault';

import {telefoneMask, cpfMask, cnpjMask} from '../../../utils/inputMask';
import {
	isValidPhone,
	isValidEmail,
	isValidCpf,
	isValidCnpj,
} from '../../../utils/validationMask';

import {convertFloatToCurrency} from '../../../utils/moneyMask';

import {dadosUsuarioPix} from '../../../api/pix';
import Loading from '../../../components/Loading';

const TransferirDestino = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const route: any = useRoute();
	const [value] = useState<number>(route?.params?.value ?? 0);
	const [key, setKey] = useState<string>('');
	const [keyValue, setKeyValue] = useState<string>('');
	const [error, setError] = useState('');
	const [loading, setLoading] = useState<boolean>(false);

	const showErrorLabel = (text: string) => {
		setError(text);
		setTimeout(() => {
			setError('');
		}, 3000);
	};

	return (
		<ScrollView contentContainerStyle={{flexGrow: 1}}>
			<View style={styles.container}>
				<HeaderTitle title="Transferir" showSeparator={true} />
				<Text style={styles.modalTitle}>
					Para quem você deseja transferir {convertFloatToCurrency(value)}{' '}
				</Text>
				<TextInput
					style={styles.input}
					value={keyValue}
					onChangeText={text => {
						if (isValidCpf(text)) {
							setKey('cpf');
							setKeyValue(cpfMask(text));
						} else if (isValidCnpj(text)) {
							setKey('cnpj');
							setKeyValue(cnpjMask(text));
						} else if (isValidEmail(text)) {
							setKey('email');
							setKeyValue(text);
						} else if (
							(text.length === 11 || isValidPhone(text)) &&
							text.replace(/\D/g, '').length === 11
						) {
							setKey('telefone');
							setKeyValue(telefoneMask(text));
						} else if (text.length > 11 && text.length < 32) {
							setKey('aleatório');
							setKeyValue(
								text
									.trim()
									.replace(/\s/g, '')
									.replace(')', '')
									.replace('(', '')
									.replace('-', ''),
							);
						} else if (text.length === 32) {
							setKey('aleatório');
							setKeyValue(text);
						} else {
							setKey('aleatório');
							setKeyValue(text);
						}
					}}
					placeholder="CPF/CNPJ, e-mail, telefone ou chave Pix"
				/>
				<Text style={styles.noKeysText}>
					{key.length > 2 ? `Tipo de chave: ${key.toUpperCase()}` : ''}
				</Text>
				<Text style={{color: '#ec407a', textAlign: 'center'}}>{error}</Text>

				<View style={{flex: 1}} />

				<ButtonDefault
					onPress={async () => {
						if (!key) {
							showErrorLabel('Chave inválida.');
							return;
						}
						setLoading(true);
						const result = await dadosUsuarioPix(key, keyValue);
						setLoading(false);
						if (result.status !== 200) {
							showErrorLabel('Não foi possível validar a chave.');
							return;
						} else if (result?.data?.data?.body) {
							navigation.navigate('TransferirConfirmar', {
								value,
								key,
								keyValue,
								data: result.data.data.body,
							});
						} else {
							showErrorLabel('Não foi possível validar a chave.');
						}
					}}
					title="Avançar"
					iconName="chevron-forward-circle-outline"
					iconSize={25}
					iconColor="white"
					buttonStyle={styles.addButton}
					textStyle={styles.addButtonText}
				/>

				<Loading visible={loading} />
			</View>
		</ScrollView>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
		backgroundColor: '#151c27',
	},
	input: {
		borderWidth: 1,
		borderColor: 'gray',
		padding: 10,
		marginTop: 16,
		marginBottom: 16,
		borderRadius: 8,
		color: 'white',
		fontSize: 16,
	},
	noKeysText: {
		fontSize: 16,
		fontStyle: 'italic',
		color: 'white',
	},
	modalTitle: {
		fontSize: 25,
		fontWeight: 'bold',
		color: 'white',
	},
	modalTitle2: {
		fontSize: 16,
		marginBottom: 8,
		color: 'white',
	},
	addButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#273d4c',
		borderRadius: 8,
		padding: 12,
		marginBottom: 16,
	},
	addButtonText: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 16,
	},
});

export default TransferirDestino;
