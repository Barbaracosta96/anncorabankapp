import { format, parseISO } from 'date-fns';

export const validaDataBr = (dataParam: string) => {
	const dataTra = new Date(dataParam);
	dataTra.setDate(dataTra.getDate());
    
	const dayOfWeek = dataTra.toLocaleDateString('pt-BR', { weekday: 'long' });
	const dayOfMonth = dataTra.getDate();
	const monthMonth = dataTra.toLocaleDateString('pt-BR', { month: 'long' });
	const year = dataTra.getFullYear();

	const dataAtual = new Date();
	//let dataAtual = format(dataAtual, 'yyyy-MM-dd');
    
	let tituloStrDate = `${dayOfMonth} de ${monthMonth} de ${year}`;
	dataAtual.setHours(0, 0, 0, 0.1);
	dataTra.setHours(0, 0, 0, 0.1);
	
	if (dataParam == format(dataAtual, 'yyyy-MM-dd')) {
		console.log('MOSTRANDO ADATA ATUAL',format(dataAtual, 'yyyy-MM-dd'))
		console.log('MOSTRANDO ADATA TRANSACAO',dataParam)
		tituloStrDate = 'Hoje';
	}
	//console.log('Data atual', dataAtual, 'data transacao', dataTra);
	return tituloStrDate;
    
    return '';
};

export const validaDiaDoMes = (dataParam: string) => {
	const dataTra = new Date(dataParam);
	dataTra.setDate(dataTra.getDate());
    
	const dayOfWeek = dataTra.toLocaleDateString('pt-BR', { weekday: 'long' });
	const dayOfMonth = dataTra.getDate();
	const monthMonth = dataTra.toLocaleDateString('pt-BR', { month: 'long' });
	const year = dataTra.getFullYear();

	const dataAtual = new Date();
	//let dataAtual = format(dataAtual, 'yyyy-MM-dd');
    
	let tituloStrDate =` ${monthMonth}`;
	dataAtual.setHours(0, 0, 0, 0.1);
	dataTra.setHours(0, 0, 0, 0.1);
	
	if (dataParam == format(dataAtual, 'yyyy-MM-dd')) {
		console.log('MOSTRANDO ADATA ATUAL',format(dataAtual, 'yyyy-MM-dd'))
		console.log('MOSTRANDO ADATA TRANSACAO',dataParam)
		tituloStrDate = 'Hoje';
	}
	//console.log('Data atual', dataAtual, 'data transacao', dataTra);
	return tituloStrDate;
    
    return '';
};

export const pegaDataAtual = () => {
	const date = new Date();
	console.log('Data atual', format(date, 'dd/MM/yyyy'));

	return format(date, 'dd/MM/yyyy');
};

export const pegaApenasData = (data: any) => {
	//var apenasData = data.toLocaleString().substr(0, 10) +1
	//console.log('recebe data ',apenasData)
	//var dataAtual = new Date();

	//const dataAtual = new Date(data);
	//console.log('recebe data', data)
	//const dia = dataAtual.getDate();
	//const mes = dataAtual.getMonth() + 1;
	//const ano = dataAtual.getFullYear();
	//const apenasData = `${ano}-${mes}-${dia}`;

	//console.log('Data atual now',format(parseISO(data), 'dd/MM/yyyy'))
	//console.log("Hoje é dia " + dia + "/" + mes + " de " + ano + ". Agora são " + horas + ":" +
	//return format(parseISO(data), 'yyyy-MM-dd');

	return format(parseISO(data), 'yyyy-MM-dd');
};

export const inverteData = (data: any) => {
	console.log('data recebe', data);
	//return format(data, 'yyyy-MM-dd');
	const dataRecebida = data;
	const dataconvertida = dataRecebida.split('/').reverse().join('-');
	return dataconvertida;
	//console.log('data acabei de formatar', dataconvertida);
};
