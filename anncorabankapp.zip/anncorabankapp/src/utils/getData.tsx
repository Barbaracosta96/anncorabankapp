const getFirstName = (fullName: string | undefined | null): string => {
  if (typeof fullName !== 'string' || fullName.trim() === '') {
    return '';
  }

  const partesNome = fullName.trim().split(' ');

  if (partesNome.length === 0) {
    return '';
  }

  return partesNome[0];
}

export { getFirstName };