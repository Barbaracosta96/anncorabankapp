const isValidPhone = (phone: string): boolean => {
	const regex = /^\([1-9]{2}\) [0-9]{5}-[0-9]{4}$/;
	return regex.test(phone);
};

const isValidEmail = (email: string): boolean => {
	const regex = /^[a-z0-9.]+@[a-z0-9]+\.[a-z]+(\.[a-z]+)?$/i;
	return regex.test(email);
};

const isValidCpf = (strCPF: string): boolean => {
	if (strCPF === undefined) return false;
	if (strCPF.length === 0) return false;

	const cpf = strCPF.replace(/\D/g, '');

	if (
		cpf === '00000000000' ||
		cpf === '11111111111' ||
		cpf === '22222222222' ||
		cpf === '33333333333' ||
		cpf === '44444444444' ||
		cpf === '55555555555' ||
		cpf === '66666666666' ||
		cpf === '77777777777' ||
		cpf === '88888888888' ||
		cpf === '99999999999'
	) {
		return false;
	}

	let sum = 0;
	let rest;

	for (let i = 1; i <= 9; i++) {
		sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
	}

	rest = (sum * 10) % 11;

	if (rest === 10 || rest === 11) {
		rest = 0;
	}

	if (rest !== parseInt(cpf.substring(9, 10))) {
		return false;
	}

	sum = 0;

	for (let i = 1; i <= 10; i++) {
		sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
	}

	rest = (sum * 10) % 11;

	if (rest === 10 || rest === 11) {
		rest = 0;
	}

	if (rest !== parseInt(cpf.substring(10, 11))) {
		return false;
	}

	return true;
};

const isValidCnpj = (cnpjValue: string): boolean => {
	if (cnpjValue === undefined) return false;
	if (cnpjValue.length === 0) return false;

	const cnpj: string = cnpjValue.replace(/[^\d]+/g, '');

	if (cnpj.length !== 14) return false;

	if (/^(\d)\1+$/.test(cnpj)) return false;

	const t: number = cnpj.length - 2;
	const d: string = cnpj.substring(t);
	const d1: number = parseInt(d.charAt(0));
	const d2: number = parseInt(d.charAt(1));

	const calc = (x: number): number => {
		const n: string = cnpj.substring(0, x);
		let y: number = x - 7;
		let s: number = 0;
		let r: number = 0;

		for (let i: number = x; i >= 1; i--) {
			s += parseInt(n.charAt(x - i)) * y--;
			if (y < 2) y = 9;
		}

		r = 11 - (s % 11);
		return r > 9 ? 0 : r;
	};

	return calc(t) === d1 && calc(t + 1) === d2;
};

const isValidDate = (data: string): any => {
	if (typeof data !== 'string' || data.length < 10) {
		return {
			valid: false,
			message: 'Data inválida.',
		};
	}
	const regex = /^\d{2}\/\d{2}\/\d{4}$/;
	if (!regex.test(data)) {
		return {
			valid: false,
			message: 'Data inválida.',
		};
	}

	const partes = data.split('/');
	const dia = parseInt(partes[0], 10);
	const mes = parseInt(partes[1], 10);
	const ano = parseInt(partes[2], 10);

	if (isNaN(dia) || isNaN(mes) || isNaN(ano)) {
		return {
			valid: false,
			message: 'Data inválida.',
		};
	}

	if (dia < 1 || dia > 31 || mes < 1 || mes > 12) {
		return {
			valid: false,
			message: 'Data inválida.',
		};
	}

	const dataNascimento = new Date(ano, mes - 1, dia);
	if (
		dataNascimento.getFullYear() !== ano ||
		dataNascimento.getMonth() !== mes - 1 ||
		dataNascimento.getDate() !== dia
	) {
		return {
			valid: false,
			message: 'Data inválida.',
		};
	}

	// Verificar se a pessoa tem pelo menos 18 anos
	const hoje = new Date();
	const idadeMinima = new Date(
		hoje.getFullYear() - 18,
		hoje.getMonth(),
		hoje.getDate(),
	);
	if (dataNascimento > idadeMinima) {
		return {
			valid: false,
			message: 'Você deve ter pelo menos 18 anos para abrir uma conta.',
		};
	}

	return {
		valid: true,
		message: '',
	};
};

const isValidFullName = (nomeCompleto: string) => {
	if (!nomeCompleto || typeof nomeCompleto !== 'string') {
		return false;
	}
	const nomes = nomeCompleto?.trim()?.split(' ');
	if (nomes.length < 2) {
		return false;
	}
	for (let i = 0; i < nomes.length; i++) {
		if (!nomes[i] || nomes[i].length < 2) {
			return false;
		}
	}
	return true;
};

const isStrongerKey = (senha: string) => {
	if (!senha || typeof senha !== 'string') {
		return false;
	}
	const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%!^&*()]).{10,}$/;
	return regex.test(senha);
};

export {
	isValidPhone,
	isValidEmail,
	isValidCpf,
	isValidCnpj,
	isValidDate,
	isValidFullName,
	isStrongerKey,
};
