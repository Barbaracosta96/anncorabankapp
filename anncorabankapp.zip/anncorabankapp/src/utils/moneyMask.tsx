const convertFloatToCurrency = (value: number): string => {
	if (value === undefined || value === null) return '-';
	try {
		const text = `R$ ${value
			.toFixed(2)
			.replace(/\./g, 'p')
			.replace(/\B(?=(\d{3})+(?!\d))/g, '.')
			.replace(/p/g, ',')}`;
		return text;
	} catch (error) {
		console.log(error);
		return '-';
	}
};

const convertCurrencyToFloat = (text: string): number => {
	if (!text) return 0;
	if (text.length === 0) return 0;
	const value = parseFloat(
		text.replace(/\./g, '').replace(/\,/g, '.').replace('R$', '')
	);
	return value;
}

export {convertFloatToCurrency, convertCurrencyToFloat};
