const telefoneMask = (text: string) => {
	if (!text) return text;
	if (text.length === 0) return text;
	let x: any = text.replace(/\D/g, '').match(/(\d{0,2})(\d{0,5})(\d{0,4})/);
	if (text.length < 16) {
		text = !x[2]
			? x[1]
			: '(' + x[1] + (x[2] ? ') ' + x[2] : '') + (x[3] ? '-' + x[3] : '');
		return text;
	}
	return text.slice(0, 15);
};

const cpfMask = (text: string) => {
	if (!text) return text;
	if (text.length === 0) return text;
	let x: any = text
		.replace(/\D/g, '')
		.match(/(\d{0,3})(\d{0,3})(\d{0,3})(\d{0,2})/);
	if (text.length <= 14) {
		text = !x[2]
			? x[1]
			: x[1] +
			  (x[2] ? '.' + x[2] : '') +
			  (x[3] ? '.' + x[3] : '') +
			  (x[4] ? '-' + x[4] : '');
		return text;
	}
	return text.slice(0, 14);
};

const cnpjMask = (text: string) => {
	if (!text) return text;
	if (text.length === 0) return text;
	let x: any = text
		.replace(/\D/g, '')
		.match(/(\d{0,2})(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,2})/);
	if (text.length <= 18) {
		text = !x[2]
			? x[1]
			: x[1] +
			  (x[2] ? '.' + x[2] : '') +
			  (x[3] ? '.' + x[3] : '') +
			  (x[4] ? '/' + x[4] : '') +
			  (x[5] ? '-' + x[5] : '');
		return text;
	}
	return text.slice(0, 18);
};

const birthDateMask = (text: string) => {
	if (!text) return text;
	if (text.length === 0) return text;
	let x: any = text.replace(/\D/g, '').match(/(\d{0,2})(\d{0,2})(\d{0,4})/);
	if (text.length <= 10) {
		text = !x[2]
			? x[1]
			: x[1] + (x[2] ? '/' + x[2] : '') + (x[3] ? '/' + x[3] : '');
		return text;
	}
	return text.slice(0, 10);
};

const cepMask = (text: string) => {
	if (!text) return text;
	if (text.length === 0) return text;
	let x: any = text.replace(/\D/g, '').match(/(\d{0,5})(\d{0,3})/);
	if (text.length <= 9) {
		text = !x[2] ? x[1] : x[1] + '-' + x[2];
		return text;
	}
	return text.slice(0, 9);
};

export {telefoneMask, cpfMask, birthDateMask, cnpjMask, cepMask};
