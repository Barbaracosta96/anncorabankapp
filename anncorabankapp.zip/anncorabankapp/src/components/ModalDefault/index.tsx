import React from 'react';
import {View, TouchableOpacity, Modal, StyleSheet} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

interface ModalDefaultProps {
	isVisible: boolean;
	setIsVisible: (value: boolean) => void;
	children: React.ReactNode;
}

const ModalDefault = (props: ModalDefaultProps) => {
	const {isVisible, setIsVisible, children} = props;

	return (
		<Modal visible={isVisible} transparent>
			<View style={styles.modalContainer}>
				<View style={styles.modalContent}>
					<TouchableOpacity
						onPress={() => setIsVisible(false)}
						style={styles.closeIcon}>
						<Icon name="times" size={30} color="#f50057" />
					</TouchableOpacity>
					<View>{children}</View>
				</View>
			</View>
		</Modal>
	);
};

const styles = StyleSheet.create({
	modalContainer: {
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
	},
	modalContent: {
		backgroundColor: '#273d4c',
		padding: 20,
		borderRadius: 10,
		width: '80%',
	},
	closeIcon: {
		position: 'absolute',
		top: 10,
		right: 10,
	},
});

export default ModalDefault;
