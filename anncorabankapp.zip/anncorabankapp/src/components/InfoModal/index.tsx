import * as React from 'react';
import {FC} from 'react';
import {View, Text, Modal, TouchableOpacity, StyleSheet} from 'react-native';

interface InfoModalProps {
	visible: boolean;
	text: string;
	onClose: () => void;
}

const InfoModal: FC<InfoModalProps> = ({visible, text, onClose}) => {
	return (
		<Modal transparent={true} visible={visible} animationType="slide">
			<View style={styles.modalContainer}>
				<View style={styles.modalContent}>
					<TouchableOpacity style={styles.closeButton} onPress={onClose}>
						<Text style={styles.closeButtonText}>X</Text>
					</TouchableOpacity>
					<Text>{text}</Text>
				</View>
			</View>
		</Modal>
	);
};

const styles = StyleSheet.create({
	modalContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
	},
	modalContent: {
		backgroundColor: '#41617f',
		padding: 20,
		borderRadius: 10,
		width: '80%',
	},
	closeButton: {
		position: 'absolute',
		top: 5,
		right: 5,
		padding: 5,
	},
	closeButtonText: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#e968b4',
	},
});

export default InfoModal;
