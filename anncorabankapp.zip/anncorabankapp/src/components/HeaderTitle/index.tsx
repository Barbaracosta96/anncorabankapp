import React from 'react';
import {
	View,
	Text,
	TouchableOpacity,
	StyleSheet,
	Dimensions,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

interface HeaderTitleProps {
	title: string;
	iconColor?: string;
	showSeparator?: boolean;
	marginTop?: number;
}

const HeaderTitle = (props: HeaderTitleProps) => {
	const {title, iconColor = '#fff', showSeparator, marginTop = 0} = props;
	const navigation = useNavigation<NativeStackNavigationProp<any>>();

	return (
		<>
			<TouchableOpacity onPress={() => navigation.goBack()}>
				<View
					style={[
						styles.header,
						{marginBottom: showSeparator ? 0 : 15, marginTop: marginTop},
					]}>
					<TouchableOpacity onPress={() => navigation.goBack()}>
						<Ionicons
							name="arrow-back"
							size={30}
							color={iconColor}
							style={styles.backButton}
						/>
					</TouchableOpacity>
					<Text style={styles.title}>{title}</Text>
				</View>
			</TouchableOpacity>
			{showSeparator ? <View style={styles.separator} /> : null}
		</>
	);
};

const styles = StyleSheet.create({
	header: {
		flexDirection: 'row',
		alignItems: 'center',
		width: Dimensions.get('window').width,
		paddingLeft: 16,
	},
	title: {
		fontSize: 20,
		color: 'white',
		textAlign: 'center',
		position: 'absolute',
		left: 0,
		right: 0,
	},
	backButton: {},
	separator: {
		borderBottomWidth: 1,
		borderColor: 'gray',
		marginBottom: 16,
		marginTop: 16,
	},
});

export default HeaderTitle;
