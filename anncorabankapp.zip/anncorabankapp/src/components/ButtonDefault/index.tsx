import React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

interface ButtonDefaultProps {
	onPress: () => void;
	title: string;
	iconName?: string;
	iconSize?: number;
	iconColor?: string;
	buttonStyle?: object;
	textStyle?: object;
	disabled?: boolean;
}

const ButtonDefault: React.FC<ButtonDefaultProps> = ({
	onPress,
	title,
	iconName,
	iconSize = 20,
	iconColor = 'white',
	buttonStyle = {},
	textStyle = {},
	disabled = false,
}) => {
	return (
		<TouchableOpacity
			onPress={onPress}
			style={[styles.addButton, buttonStyle, disabled && {opacity: 0.5}]}
			disabled={disabled}>
			{iconName && (
				<Icon
					name={iconName}
					size={iconSize}
					color={iconColor}
					style={styles.addIcon}
				/>
			)}
			<Text style={[styles.addButtonText, textStyle]}>{title}</Text>
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	addButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#273d4c',
		borderRadius: 8,
		padding: 12,
		marginBottom: 16,
		marginTop: 8,
	},
	addIcon: {
		marginRight: 8,
	},
	addButtonText: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 16,
	},
});

export default ButtonDefault;
