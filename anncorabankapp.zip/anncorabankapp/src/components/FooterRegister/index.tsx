import * as React from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	useWindowDimensions,
} from 'react-native';
import IconMaterial from 'react-native-vector-icons/MaterialIcons';
import IconAntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

const FooterRegister: React.FC = () => {
	const {width, height} = useWindowDimensions();
	const navigation = useNavigation<NativeStackNavigationProp<any>>();

	const styles = StyleSheet.create({
		iconContainer: {
			flexDirection: 'row',
			justifyContent: 'center',
			marginLeft: width * 0.03,
			maxWidth: width * 0.8,
			marginBottom: height * 0.03,
		},
		iconRow: {
			flexDirection: 'row',
			justifyContent: 'center',
			alignContent: 'center',
			marginBottom: 20,
			marginTop: 20,
			width: width * 0.4,
		},
		iconTouch: {
			alignItems: 'center',
			marginLeft: 5,
		},
	});

	return (
		<View style={styles.iconContainer}>
			<View style={styles.iconRow}>
				<IconMaterial name="privacy-tip" size={20} color="#fff" />
				<TouchableOpacity style={styles.iconTouch}>
					<Text
						onPress={() =>
							navigation.navigate('LoginContainer', {
								screen: 'Privacidade',
							})
						}
						style={{color: '#fff'}}>
						Política de Privacidade
					</Text>
				</TouchableOpacity>
			</View>
			<View style={styles.iconRow}>
				<IconAntDesign name="customerservice" size={20} color="#fff" />
				<TouchableOpacity style={styles.iconTouch}>
					<Text
						onPress={() =>
							navigation.navigate('LoginContainer', {
								screen: 'Atendimento',
							})
						}
						style={{color: '#fff'}}>
						Atendimento
					</Text>
				</TouchableOpacity>
			</View>
		</View>
	);
};

export default FooterRegister;
