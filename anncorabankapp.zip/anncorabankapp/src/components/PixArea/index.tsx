import * as React from 'react';
import {
	View,
	Text,
	TouchableOpacity,
	StyleSheet,
	Dimensions,
	Image,
} from 'react-native';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
// @ts-ignore
import Icon3 from 'react-native-vector-icons/FontAwesome6';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

const Home: React.FC = () => {
	const navigation = useNavigation<NativeStackNavigationProp<any>>();

	const iconColor = '#fff';
	const iconSize = 30;

	return (
		<View>
			<View style={{flexDirection: 'row', marginTop: 20}}>
				<Image
					source={require('../../assets/icons/pix.png')}
					style={{width: 24, height: 24}}
				/>
				<Text style={styles.title}>PIX</Text>
			</View>
			<View style={styles.card}>
				<View style={styles.firstPart}>
					<View style={styles.firstPartBackground}>
						<View style={styles.container}>
							<TouchableOpacity style={styles.iconContainer}>
								<Icon2
									name="qrcode-scan"
									size={iconSize}
									color={iconColor}
									style={styles.icon}
								/>
								<Text style={styles.label}>Pagar{'\n'}QR Code</Text>
							</TouchableOpacity>

							<TouchableOpacity
								style={{...styles.iconContainer, backgroundColor: '#426385'}}
								onPress={() => {
									navigation.navigate('Transferir');
								}}>
								<Icon3
									name="money-bill-transfer"
									size={iconSize}
									color={iconColor}
									style={styles.icon}
								/>
								<Text style={styles.label}>Transferir</Text>
							</TouchableOpacity>

							<TouchableOpacity style={styles.iconContainer}>
								<Icon3
									name="hand-holding-medical"
									size={iconSize}
									color={iconColor}
									style={styles.icon}
								/>
								<Text style={styles.label}>Receber</Text>
							</TouchableOpacity>

							<TouchableOpacity style={styles.iconContainer}>
								<Icon3
									name="money-bill-1-wave"
									size={iconSize}
									color={iconColor}
									style={styles.icon}
								/>
								<Text style={styles.label}>Saque e{'\n'}troco</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>
				<View style={styles.secondPart}>
					<TouchableOpacity
						onPress={() => {
							navigation.navigate('MinhasChaves');
						}}>
						<Text style={styles.exibirExtratoText}>Minhas Chaves</Text>
					</TouchableOpacity>
					<View style={styles.separator}></View>
					<TouchableOpacity>
						<Text style={[styles.exibirExtratoText, {color: 'gray'}]}>
							Meus Limites PIX
						</Text>
					</TouchableOpacity>
				</View>
			</View>
		</View>
	);
};


const styles = StyleSheet.create({
	card: {
		width: '85%',
		height: 170,
		borderRadius: 10,
	},
	firstPart: {
		backgroundColor: '#1e2d3a',
		flex: 1,
		borderTopLeftRadius: 10,
		borderTopRightRadius: 10,
	},
	firstPartBackground: {
		backgroundColor: '#1e2d3a',
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		borderTopLeftRadius: 10,
		borderTopRightRadius: 10,
	},
	secondPart: {
		backgroundColor: '#9dbbd2',
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		padding: 16,
		borderBottomLeftRadius: 10,
		borderBottomRightRadius: 10,
	},
	text: {
		color: '#fff',
		fontSize: 14,
	},
	balance: {
		color: '#fff',
		fontSize: 24,
		fontWeight: 'bold',
	},
	eyeIcon: {},
	exibirExtrato: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	exibirExtratoText: {
		color: '#030c16',
		fontSize: 16,
		marginRight: 8,
	},
	container: {
		flexDirection: 'row',
		// flexWrap: 'wrap',
		width: Dimensions.get('window').width * 0.88,
		justifyContent: 'space-evenly',
		alignItems: 'center',
		borderRadius: 10,
		padding: 15,
	},
	iconContainer: {
		backgroundColor: '#9b9b9b',
		justifyContent: 'center',
		alignItems: 'center',
		width: Dimensions.get('window').width / 5.5,
		height: Dimensions.get('window').width / 5.5,
		transform: [{scale: 0.9}],
		borderRadius: 10,
	},
	icon: {
		borderRadius: 50,
		padding: 5,
	},
	label: {
		fontSize: 12,
		color: '#fff',
		textAlign: 'center',
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		color: '#fff',
		alignSelf: 'flex-start',
		marginLeft: 10,
		marginBottom: 10,
	},
	separator: {
		height: 20,
		width: 2,
		backgroundColor: 'black',
	},
});

export default Home;
