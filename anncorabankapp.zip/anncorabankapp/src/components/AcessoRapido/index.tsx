import * as React from 'react';
import {
	View,
	Text,
	TouchableOpacity,
	StyleSheet,
	FlatList,
	useWindowDimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
// @ts-ignore
import Icon3 from 'react-native-vector-icons/FontAwesome6';
import Icon4 from 'react-native-vector-icons/Feather';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';
import LinearGradient from 'react-native-linear-gradient';

type IconType = 'icon' | 'icon2' | 'icon3' | 'icon4';

const Home: React.FC = () => {
	const { width, height } = useWindowDimensions();
	const navigation = useNavigation<NativeStackNavigationProp<any>>();

	const icons = [
		{ name: 'bank-transfer', label: 'Transferir', type: 'icon2' as IconType },
		{ name: 'barcode-sharp', label: 'Pagar', type: 'icon' as IconType },
		{ name: 'script-text-outline', label: 'Ver extrato', type: 'icon2' as IconType, route: 'Extrato' },
		{ name: 'credit-card-multiple-outline', label: 'Cartões', type: 'icon2' as IconType },
		{ name: 'circle-dollar-to-slot', label: 'Depositar', type: 'icon3' as IconType },
		{ name: 'mobile-screen', label: 'Recarga\nde celular', type: 'icon3' as IconType },
		{ name: 'hand-holding-dollar', label: 'Cobrar', type: 'icon3' as IconType },
		{ name: 'more-horizontal', label: 'Todos', type: 'icon4' as IconType },
	];

	const iconColor = '#fff';
	const iconSize = 30;

	const renderItem = ({ item }: any) => {
		const iconContainerWidth = width / 5;
		const iconContainerHeight = width / 5;

		const styles = StyleSheet.create({
			iconContainer: {
				backgroundColor: '#426385',
				justifyContent: 'center',
				alignItems: 'center',
				width: iconContainerWidth,
				height: iconContainerHeight,
				transform: [{ scale: 0.8 }],
				borderRadius: 10,
			},
			icon: {
				borderRadius: 50,
				padding: 10,
			},
			label: {
				fontSize: 12,
				color: '#fff',
				textAlign: 'center',
			},
		});

		return (
			<TouchableOpacity
				style={[styles.iconContainer, { backgroundColor: item.route ? '#426385' : '#9b9b9b' }]}
				onPress={() => {
					if (item.route) {
						navigation.navigate(item.route);
					}
				}}>
				{(() => {
					switch (item.type) {
						case 'icon':
							return <Icon name={item.name} size={iconSize} color={iconColor} style={styles.icon} />;
						case 'icon2':
							return <Icon2 name={item.name} size={iconSize} color={iconColor} style={styles.icon} />;
						case 'icon3':
							return <Icon3 name={item.name} size={iconSize} color={iconColor} style={styles.icon} />;
						case 'icon4':
							return <Icon4 name={item.name} size={iconSize} color={iconColor} style={styles.icon} />;
						default:
							return null;
					}
				})()}
				<Text style={styles.label}>{item.label}</Text>
			</TouchableOpacity>
		);
	};

	return (
		<View>
			<Text
				style={{
					fontSize: 20,
					fontWeight: 'bold',
					color: '#fff',
					alignSelf: 'flex-start',
					marginTop: 10,
					marginBottom: 10,
				}}
			>
				Dia a dia
			</Text>
			<LinearGradient
				colors={['rgba(45, 67, 87, 0.5)', 'rgba(45, 67, 87, 0.5)']}
				style={styles.container}
			>
				<FlatList
					data={icons}
					numColumns={4}
					keyExtractor={(item, index) => index.toString()}
					renderItem={renderItem}
					contentContainerStyle={styles.contentContainerStyle}
				/>
			</LinearGradient>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		width: '100%',
		justifyContent: 'space-evenly',
		alignItems: 'center',
		borderRadius: 10,
		padding: 15,
	},
	contentContainerStyle: {
		width: '100%',
		justifyContent: 'space-between',
		alignItems: 'center',
	},
});

export default Home;
