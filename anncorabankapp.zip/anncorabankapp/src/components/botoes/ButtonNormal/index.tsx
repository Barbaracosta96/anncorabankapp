import * as React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';

interface ButtonNormalProps {
	onPress: () => void;
	text: string;
	color: string;
}

const ButtonNormal: React.FC<ButtonNormalProps> = ({onPress, text, color}) => {
	return (
		<TouchableOpacity
			style={[styles.buttonNormal, {backgroundColor: color}]}
			onPress={onPress}>
			<Text style={styles.buttonText}>{text}</Text>
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	buttonNormal: {
		borderWidth: 2,
		paddingVertical: 10,
		paddingHorizontal: 20,
		alignItems: 'center',
		justifyContent: 'center',
		borderRadius: 20,
		borderColor: 'transparent',
	},
	buttonText: {
		color: 'white',
	},
});

export default ButtonNormal;
