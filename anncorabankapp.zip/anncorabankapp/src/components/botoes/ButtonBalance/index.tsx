import React from 'react';
import {useState, useEffect} from 'react';
import {TouchableOpacity, Text, StyleSheet, View, Image} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import {LocalSvg} from 'react-native-svg';
import {useNavigation} from '@react-navigation/native';
import {useFocusEffect} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

import {getSaldo} from '../../../api/carteira';
import {convertFloatToCurrency} from '../../../utils/moneyMask';

interface ButtonMenuProps {
	onPress: () => void;
	text: string;
	nameIcon?: string;
	svgIcon?: any;
	style?: any;
	textStyle?: any;
}

const ButtonBalance: React.FC<ButtonMenuProps> = ({
	onPress,
	text,
	nameIcon,
	svgIcon,
	style,
	textStyle,
}) => {
	const [saldo, setSaldo] = useState<string>('-');
	const [showBalance, setShowBalance] = useState(false);
	const [isFocused, setIsFocused] = useState(false);

	useFocusEffect(
		React.useCallback(() => {
			setIsFocused(true);
			return () => setIsFocused(false);
		}, []),
	);

	const handleToggleBalance = () => {
		setShowBalance(!showBalance);
	};

	useEffect(() => {
		const getSaldoApi = async () => {
			const response = await getSaldo();
			if (response?.data?.data?.total) {
				setSaldo(convertFloatToCurrency(response?.data?.data?.total));
			}
		};
		try {
			getSaldoApi();
		} catch (error) {
			console.log(error);
		}
	}, [isFocused]);

	return (
		<View>
			<TouchableOpacity
				style={[styles.button, style]}
				onPress={handleToggleBalance}>
				<View style={styles.buttonContent}>
					<View style={styles.buttonContent}>
						{svgIcon ? (
							<LocalSvg width={20} height={20} asset={svgIcon} />
						) : (
							<Icon name={nameIcon ?? ''} size={20} color="white" />
						)}
						<Text style={[styles.buttonText, textStyle]}>{text}</Text>
					</View>
					<View style={styles.buttonContent}>
						<Text style={styles.balance}>
							{showBalance ? saldo : 'R$ ****'}
						</Text>
						<Icon
							name={showBalance ? 'eye' : 'eye-off'}
							size={20}
							color="#fff"
						/>
					</View>
				</View>
			</TouchableOpacity>
		</View>
	);
};

const styles = StyleSheet.create({
	button: {
		backgroundColor: '#1e2d3a',
		borderRadius: 8,
		paddingHorizontal: 16,
		paddingVertical: 12,
		height: 50,
	},
	buttonContent: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
	},
	buttonText: {
		color: 'white',
		marginLeft: 10,
		marginRight: 10,
		fontWeight: 'bold',
	},
	balance: {
		color: '#fff',
		fontSize: 20,
		fontWeight: 'bold',
		marginRight: 15,
	},
});

export default ButtonBalance;
