import * as React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';

interface ButtonOutlineProps {
	onPress: () => void;
	text: string;
}

const ButtonOutline: React.FC<ButtonOutlineProps> = ({onPress, text}) => {
	return (
		<TouchableOpacity style={styles.buttonOutline} onPress={onPress}>
			<Text style={styles.buttonText}>{text}</Text>
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	buttonOutline: {
		borderWidth: 2,
		borderColor: 'white',
		borderRadius: 20,
		paddingVertical: 10,
		paddingHorizontal: 20,
		alignItems: 'center',
	},
	buttonText: {
		color: 'white',
	},
});

export default ButtonOutline;
