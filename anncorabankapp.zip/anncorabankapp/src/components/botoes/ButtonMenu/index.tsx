import React from 'react';
import {TouchableOpacity, Text, StyleSheet, View, Image} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { LocalSvg } from 'react-native-svg';

interface ButtonMenuProps {
	onPress: () => void;
	text: string;
	nameIcon?: string;
	svgIcon?: any;
	style?: any;
	textStyle?: any;
}

const ButtonMenu: React.FC<ButtonMenuProps> = ({
	onPress,
	text,
	nameIcon,
	svgIcon,
	style,
	textStyle,
}) => {
	return (
		<TouchableOpacity style={[styles.button, style]} onPress={onPress}>
			<View style={styles.buttonContent}>
				<View style={styles.buttonContent}>
					{svgIcon ? (
						<LocalSvg width={20} height={20} asset={svgIcon} />
					) : (
						<Icon name={nameIcon ?? ''} size={20} color="white" />
					)}
					<Text style={[styles.buttonText, textStyle]}>{text}</Text>
				</View>
				<Icon name="chevron-forward-outline" size={20} color="white" />
			</View>
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	button: {
		backgroundColor: '#1e2d3a',
		borderRadius: 8,
		paddingHorizontal: 16,
		paddingVertical: 12,
	},
	buttonContent: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
	},
	buttonText: {
		color: 'white',
		marginLeft: 10,
		marginRight: 10,
		fontWeight: 'bold',
	},
});

export default ButtonMenu;
