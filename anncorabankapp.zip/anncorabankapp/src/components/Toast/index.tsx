import * as React from 'react';
import {useEffect, useState} from 'react';
import {Text, Animated, StyleSheet, Dimensions} from 'react-native';

interface ToastProps {
	message: string;
	duration: number;
	onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({message, duration, onClose}) => {
	const [fadeAnim] = useState(new Animated.Value(0));

	useEffect(() => {
		Animated.sequence([
			Animated.timing(fadeAnim, {
				toValue: 1,
				duration: 500,
				useNativeDriver: true,
			}),
			Animated.delay(duration),
			Animated.timing(fadeAnim, {
				toValue: 0,
				duration: 500,
				useNativeDriver: true,
			}),
		]).start(() => onClose());
	}, [duration, fadeAnim, onClose]);

	return (
		<Animated.View
			style={[
				styles.container,
				{
					opacity: fadeAnim,
					zIndex: 999,
				},
			]}>
			<Text style={styles.text}>{message}</Text>
		</Animated.View>
	);
};

const styles = StyleSheet.create({
	container: {
		backgroundColor: '#2b2e32',
		padding: 10,
		borderRadius: 10,
		position: 'absolute',
		bottom: Dimensions.get('screen').height / 6 ?? 20,
		left: 20,
		right: 20,
	},
	text: {
		color: 'white',
		textAlign: 'center',
	},
});

export default Toast;
