import * as React from 'react';
import {FC} from 'react';
import { View, ActivityIndicator, ViewStyle } from 'react-native';

interface LoadingProps {
	visible: boolean;
}

const Loading: FC<LoadingProps> = ({ visible }) => {
	if (!visible) {
		return <View />;
	}

	const containerStyle: ViewStyle = {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		backgroundColor: 'rgba(39, 59, 75, 0.5)',
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 9999,
	};

	const indicatorStyle: ViewStyle = {
		justifyContent: 'center',
		alignSelf: 'center',
		backgroundColor: '#fff',
		width: 50,
		height: 50,
		borderRadius: 15,
		borderWidth: 2,
		borderColor: '#ddddff',
	};

	return (
		<View style={containerStyle}>
			<ActivityIndicator size="large" color="rgba(39, 59, 75)" style={indicatorStyle} />
		</View>
	);
};

export default Loading;
