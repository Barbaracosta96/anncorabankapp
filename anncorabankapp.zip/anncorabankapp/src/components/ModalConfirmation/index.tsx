import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import ModalDefault from '../ModalDefault';

interface ModalConfirmationProps {
	isVisible: boolean;
	setIsVisible: (isVisible: boolean) => void;
	onPressYes: () => void;
	onPressNot: () => void;
	title: string;
	inverted?: boolean;
}

const ModalConfirmation: React.FC<ModalConfirmationProps> = ({
	isVisible,
	setIsVisible,
	onPressYes,
	onPressNot,
	title,
	inverted = false,
}) => {
	return (
		<ModalDefault isVisible={isVisible} setIsVisible={setIsVisible}>
			<Text style={styles.modalTitle}>{title}</Text>
			<View style={styles.modalButtons}>
				{inverted ? (
					<>
						<TouchableOpacity onPress={onPressNot} style={styles.cancelButton}>
							<Text style={{color: 'white'}}>Não</Text>
						</TouchableOpacity>
						<TouchableOpacity onPress={onPressYes} style={styles.confirmButton}>
							<Text style={{color: 'white'}}>Sim</Text>
						</TouchableOpacity>
					</>
				) : (
					<>
						<TouchableOpacity onPress={onPressYes} style={styles.confirmButton}>
							<Text style={{color: 'white'}}>Sim</Text>
						</TouchableOpacity>
						<TouchableOpacity onPress={onPressNot} style={styles.cancelButton}>
							<Text style={{color: 'white'}}>Não</Text>
						</TouchableOpacity>
					</>
				)}
			</View>
		</ModalDefault>
	);
};

const styles = StyleSheet.create({
	modalTitle: {
		fontSize: 16,
		fontWeight: 'bold',
		marginBottom: 16,
		color: 'white',
	},
	modalButtons: {
		flexDirection: 'row',
		justifyContent: 'center',
	},
	confirmButton: {
		backgroundColor: '#f50057',
		padding: 12,
		alignItems: 'center',
		borderRadius: 8,
		marginHorizontal: 8,
	},
	cancelButton: {
		backgroundColor: '#151c27',
		padding: 12,
		alignItems: 'center',
		borderRadius: 8,
		marginHorizontal: 8,
	},
});

export default ModalConfirmation;
