import * as React from 'react';
import {useState, useEffect} from 'react';
import {
	View,
	Text,
	TouchableOpacity,
	StyleSheet,
	Dimensions,
	Image,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import {useNavigation} from '@react-navigation/native';
import {useFocusEffect} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack/lib/typescript/src/types';

import {getSaldo} from '../../api/carteira';
import {convertFloatToCurrency} from '../../utils/moneyMask';

const SaldoEmConta: React.FC = () => {
	const [saldo, setSaldo] = useState<string>('-');
	const [showBalance, setShowBalance] = useState(false);
	const navigation = useNavigation<NativeStackNavigationProp<any>>();
	const [isFocused, setIsFocused] = useState(false);

	useFocusEffect(
		React.useCallback(() => {
			setIsFocused(true);
			return () => setIsFocused(false);
		}, []),
	);

	const handleToggleBalance = () => {
		setShowBalance(!showBalance);
	};

	useEffect(() => {
		const getSaldoApi = async () => {
			const response = await getSaldo();
			if (response?.data?.data?.total) {
				setSaldo(convertFloatToCurrency(response?.data?.data?.total));
			}
		};
		try {
			getSaldoApi();
		} catch (error) {
			console.log(error);
		}
	}, [isFocused]);

	return (
		<View style={styles.card}>
			<View style={styles.firstPart}>
				<View style={styles.firstPartBackground}>
					<View>
						<View>
							<Text style={styles.text}>🇧🇷 Saldo em conta corrente</Text>
						</View>
						<Text style={styles.balance}>
							{showBalance ? saldo : 'R$ ****'}
						</Text>
					</View>
					<View>
						<TouchableOpacity
							onPress={handleToggleBalance}
							style={styles.eyeIcon}>
							<Icon
								name={showBalance ? 'eye' : 'eye-off'}
								size={30}
								color="#273d4c"
							/>
						</TouchableOpacity>
					</View>
				</View>
			</View>
			<TouchableOpacity
				onPress={() => {
					navigation.navigate('Extrato');
				}}>
				<View style={styles.secondPart}>
					<Text style={styles.exibirExtratoText}>Exibir extrato</Text>
					<View style={styles.exibirExtrato}>
						<Icon2 name="arrow-right" size={20} color="#fff" />
					</View>
				</View>
			</TouchableOpacity>
		</View>
	);
};

const styles = StyleSheet.create({
	card: {
		width: Dimensions.get('window').width * 0.95,
		height: 170,
		borderRadius: 10,
		padding: 16,
	},
	firstPart: {
		backgroundColor: '#9dbbd2',
		flex: 1,
		borderTopLeftRadius: 10,
		borderTopRightRadius: 10,
		paddingHorizontal: 16,
		paddingTop: 16,
		paddingBottom: 10,
	},
	firstPartBackground: {
		backgroundColor: '#9dbbd2',
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
	},
	secondPart: {
		backgroundColor: '#283c4c',
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		padding: 16,
		borderBottomLeftRadius: 10,
		borderBottomRightRadius: 10,
	},
	text: {
		color: '#030c16',
		fontSize: 14,
	},
	balance: {
		color: '#030c16',
		fontSize: 24,
		fontWeight: 'bold',
	},
	eyeIcon: {},
	exibirExtrato: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	exibirExtratoText: {
		color: '#fff',
		fontSize: 16,
		marginRight: 8,
	},
});

export default SaldoEmConta;
