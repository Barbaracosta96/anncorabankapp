export interface UserDataRegister {
  usuario: {
    email: string;
    senha: string;
  };
  nome_completo: string;
  cpf: string;
  telefone: string;
  nome_mae: string;
  data_nascimento: string;
  endereco: {
    cep: string;
    logradouro: string;
    cidade: string;
    sigla_uf: string;
  };
}

export interface DispositivoProps {
  marca: string;
  modelo: string;
  imei: string;
  numero_serie: string;
}
