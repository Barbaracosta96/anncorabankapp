export type KeyType = 'cpf' | 'email' | 'telefone' | 'aleatoria';

export interface CadastrarChavePix {
	tipo_chave: KeyType;
	chave?: string;
}